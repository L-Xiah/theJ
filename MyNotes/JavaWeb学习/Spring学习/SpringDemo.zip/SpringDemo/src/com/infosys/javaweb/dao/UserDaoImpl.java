package com.infosys.javaweb.dao;

public class UserDaoImpl implements UserDao {

	public UserDaoImpl() {
	}

	@Override
	public void sayHello(String param) {
		System.out.println(param);
	}
}
