package com.infosys.javaweb.dao;

public interface UserDao {
	public void sayHello(String param);
}
