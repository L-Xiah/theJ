package com.infosys.javaweb.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infosys.javaweb.model.Student;

@Service
public class StudentService {
	
	@Autowired
	private StudentDao studentDao;
	
	public StudentService() {
	}

	public void save(Student student) {
		if (student == null) {
			System.out.println("Student is null");
		}

		studentDao.save(student);
	}
}
