package com.infosys.javaweb.dao;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component
public class BeanAutowiredInvoker {
	
	@Autowired
	@Qualifier("beanAutowiredImplTwo")
	private List<IBeanAutowired> list;

	@Autowired
	private Map<String, IBeanAutowired> map;

	public void showList() {
		for (IBeanAutowired autowired : list) {
			System.out.println(autowired.getClass().getName());
		}
	}

	public void showMap() {
		for (Map.Entry<String, IBeanAutowired> entry : map.entrySet()) {
			System.out.println(entry.getKey() + " " + entry.getValue().getClass().getName());
		}
	}

	@Autowired
	@Qualifier("beanAutowiredImplTwo")
	private IBeanAutowired autowired;

	public void showOne() {
		System.out.println(autowired.getClass().getName());
	}
}
