package com.infosys.javaweb.dao;

import org.springframework.stereotype.Repository;

import com.infosys.javaweb.model.Student;

@Repository
public class StudentDao {

	public StudentDao() {
	}

	public void save(Student student) {
		System.out.println(student.toString() + ": [" + student.hashCode() + "]");
	}
}
