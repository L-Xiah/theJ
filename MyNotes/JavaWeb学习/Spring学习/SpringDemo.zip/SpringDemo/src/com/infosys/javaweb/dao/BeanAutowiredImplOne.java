package com.infosys.javaweb.dao;

import org.springframework.stereotype.Component;

@Component
public class BeanAutowiredImplOne implements IBeanAutowired {

	@Override
	public void say(String sth) {
	}

}
