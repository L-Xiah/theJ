package com.infosys.javaweb.dao;

public interface IBeanAutowired {
	public void say(String sth);
}
