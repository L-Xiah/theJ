package com.infosys.javaweb.dao;

import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;

public class UserDaoImpl2 implements UserDao, InitializingBean, DisposableBean {

	public UserDaoImpl2() {
		System.out.println("UserDaoImpl2()");
	}

	@Override
	public void sayHello(String param) {
		System.out.println(param);
	}

	@Override
	public void afterPropertiesSet() throws Exception {
		System.out.println("Bean afterPropertiesSet()");
	}

	@Override
	public void destroy() throws Exception {
		System.out.println("Bean destory()");
	}
}
