package com.infosys.javaweb.service;


import com.infosys.javaweb.dao.UserDao;

public class UserService {
	private UserDao userDao;
	
	public UserService() {
	}

	public UserService(UserDao userDao) {
		this.userDao = userDao;
	}

	public UserDao getUserDao() {
		return userDao;
	}

	public void setUserDao(UserDao userDao) {
		this.userDao = userDao;
	}
	
	public void say(String param) {
		userDao.sayHello(param);
	}
}
