package com.infosys.javaweb.dao;

import org.springframework.stereotype.Component;

@Component
public class BeanAnnotation {
	
	public BeanAnnotation() {
	}

	public void say(String param) {
		System.out.println(BeanAnnotation.class.getSimpleName() + ":" + param);
	}
}
