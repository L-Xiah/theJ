package com.infosys.javaweb.test;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.infosys.javaweb.dao.UserDao;
import com.infosys.javaweb.dao.UserDaoImpl;
import com.infosys.javaweb.dao.UserDaoImpl2;
import com.infosys.javaweb.service.UserService;

public class UserDaoTest {
	private ClassPathXmlApplicationContext context;

	@Before
	public void init() {
		System.out.println("Spring frame init");
		context = new ClassPathXmlApplicationContext(
				"classpath*:spring-ioc2.xml");
	}

	@After
	public void destory() {
		System.out.println("Spring frame destory");
		context.destroy();
	}

	@Test
	public void testHello() {
		UserDao dao = (UserDao) context.getBean("userdao");
		dao.sayHello("��ã����磡");
	}
	
	@Test
	public void testInjection() {
		UserService service = context.getBean(UserService.class);
		service.say("Hello, world! - property");
	}

	@Test
	public void testInjection2() {
		UserService dao = context.getBean(UserService.class);
		dao.getUserDao().sayHello("Hello, world! - constructor");
	}

	@Test
	public void testLifeCycle() {
		context.getBean(UserDaoImpl2.class).sayHello("sayHello()");
	}
}
