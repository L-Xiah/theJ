package com.infosys.javaweb.test;

import org.junit.Test;

import com.infosys.javaweb.dao.BeanAutowiredInvoker;
import com.infosys.javaweb.dao.BeanAnnotation;
import com.infosys.javaweb.dao.StudentService;
import com.infosys.javaweb.model.Student;

public class SpringBeanAnnoTest extends BaseSpringUnitTest {

	public SpringBeanAnnoTest() {
		super("classpath*:spring-beanannotation.xml");
	}

	@Test
	public void testSay() {
		BeanAnnotation bean = super.getBean(BeanAnnotation.class);
		bean.say("���");
	}

	@Test
	public void saveStudent() {
		Student student = new Student(1, "James");
		StudentService service = getBean(StudentService.class);
		service.save(student);
	}

	@Test
	public void autowiredList() {
		BeanAutowiredInvoker service = getBean(BeanAutowiredInvoker.class);
		service.showList();
	}

	@Test
	public void autowiredMap() {
		BeanAutowiredInvoker service = getBean(BeanAutowiredInvoker.class);
		service.showMap();
	}

	@Test
	public void autowiredOne() {
		BeanAutowiredInvoker service = getBean(BeanAutowiredInvoker.class);
		service.showOne();
	}
}
