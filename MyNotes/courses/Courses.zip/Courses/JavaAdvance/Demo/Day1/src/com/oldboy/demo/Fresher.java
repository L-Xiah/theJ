package com.oldboy.demo;

public class Fresher {

	public static void main(String[] args) {
		Fresher fresher = new Fresher();
		
	}
}
