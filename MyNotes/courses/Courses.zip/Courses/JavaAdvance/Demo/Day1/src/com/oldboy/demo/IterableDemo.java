package com.oldboy.demo;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Set;

public class IterableDemo {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Iterator it;
		ListIterator lit;
		Collection con;
		Object obj = new Object();
		System.out.println(obj);
		Set set;
		List list;
		ArrayList al;
	}

}
