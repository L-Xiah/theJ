package com.infosys.enr.mapdemo;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;

import com.infosys.enr.comparabledemo.Fresher;

public class TreeMapDemo {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// ����TreeMap����
		TreeMap<String, Fresher> map = new TreeMap<String, Fresher>();

		Fresher fresherFirst = new Fresher(20, 8, "James");
		Fresher fresherSec = new Fresher(10, 3, "Wade");
		Fresher fresherThird = new Fresher(40, 5, "DK");
		// ���Ӽ�ֵ��
		map.put(fresherFirst.getFresherName(), fresherFirst);
		map.put(fresherSec.getFresherName(), fresherSec);
		map.put(fresherThird.getFresherName(), fresherThird);
		System.out.println(map.size());
		System.out.println(map.isEmpty());
		System.out.println(map.containsKey("James"));
		System.out.println(map.containsValue(fresherThird));
		
		Set<String> keys = map.keySet();
		Iterator<String> itKey = keys.iterator();
		while (itKey.hasNext()) {
			String key = itKey.next();
			Fresher fresher = map.get(key);
			System.out.println("key:" + key);
			System.out.println("Fresher's information shown as bellow:");
			System.out.println(fresher);
		}
		// value�ļ���
		Collection<Fresher> freshers = map.values();
		Iterator<Fresher> itFreshers = freshers.iterator();
		while (itFreshers.hasNext()) {
			Fresher fresher = itFreshers.next();
			System.out.println(fresher);
		}
		// Entry���͵ļ��ϣ�key-value���͵ļ��ϣ�
		Set<Map.Entry<String, Fresher>> pairs =  map.entrySet();
		Iterator<Map.Entry<String, Fresher>> items = pairs.iterator();
		while (items.hasNext()) {
			Map.Entry<String, Fresher> item = items.next();
			String key = item.getKey();
			Fresher fresher = item.getValue();
			System.out.println("key:" + key);
			System.out.println("Fresher's information shown as bellow:");
			System.out.println(fresher);
		}
		// 
		ArrayList<Map.Entry<String, Fresher>> list = new ArrayList<Map.Entry<String, Fresher>>(pairs);
		Collections.sort(list, new Comparator<Map.Entry<String, Fresher>>() {

			@Override
			public int compare(Entry<String, Fresher> o1,
					Entry<String, Fresher> o2) {
				if (o1.getValue().getFresherAge() > o2.getValue().getFresherAge()) {
					return 1;
				} else if (o1.getValue().getFresherAge() < o2.getValue().getFresherAge()) {
					return -1;
				} else {
					return 0;
				}
			}
		});
		for (Map.Entry<String, Fresher> me : list) {
			System.out.println(me.getKey());
			System.out.println(me.getValue());
		}
	}

}
