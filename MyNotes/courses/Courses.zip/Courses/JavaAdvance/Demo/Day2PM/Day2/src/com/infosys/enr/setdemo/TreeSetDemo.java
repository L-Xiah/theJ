package com.infosys.enr.setdemo;

import java.util.Comparator;
import java.util.Iterator;
import java.util.TreeSet;

import com.infosys.enr.comparabledemo.Fresher;

public class TreeSetDemo {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TreeSet<Fresher> freshers = new TreeSet<Fresher>(new Comparator<Fresher>() {

			@Override
			public int compare(Fresher o1, Fresher o2) {
				if (o1.getFresherAge() >= o2.getFresherAge()){
					return 1;
				} else if (o1.getFresherAge() < o2.getFresherAge()) {
					return -1;
				} else {
					return 0;
				}
			}
		});
		Fresher frsherFirst = new Fresher(10, 8, "James");
		Fresher frsherSec = new Fresher(10, 3, "Wade");
		Fresher frsherThird = new Fresher(40, 5, "DK");
		freshers.add(frsherFirst);
		freshers.add(frsherSec);
		freshers.add(frsherThird);
		Iterator<Fresher> it = freshers.iterator();
		while (it.hasNext()) {
			Fresher fresher = it.next();
			System.out.println(fresher);
		}
		/*TreeSet set = new TreeSet();
		set.add("F");
		set.add("C");
		set.add("A");
		set.add("B");
		set.add("D");
		Iterator it = set.iterator();
		while (it.hasNext()) {
			System.out.println(it.next());
		}*/
	}

}
