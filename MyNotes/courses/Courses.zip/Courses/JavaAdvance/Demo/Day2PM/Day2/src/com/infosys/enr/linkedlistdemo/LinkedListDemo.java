package com.infosys.enr.linkedlistdemo;

import java.util.ArrayList;
import java.util.LinkedList;

import com.infosys.enr.comparabledemo.Fresher;

public class LinkedListDemo {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// ��������Fresher����
		Fresher frsherFirst = new Fresher(20, 8, "James");
		Fresher frsherSec = new Fresher(10, 3, "Wade");
		Fresher frsherThird = new Fresher(40, 5, "DK");
		// ����һ��LinkedList���϶���
		LinkedList<Fresher> freshers = new LinkedList<Fresher>();
		// ������Ԫ�����ӵ�����
		freshers.add(frsherFirst);
		freshers.addFirst(frsherSec);
		freshers.addLast(frsherThird);
		System.out.println(freshers.size());
		freshers.removeFirst();
		System.out.println(frsherSec);
		System.out.println(freshers.size());
	}

}
