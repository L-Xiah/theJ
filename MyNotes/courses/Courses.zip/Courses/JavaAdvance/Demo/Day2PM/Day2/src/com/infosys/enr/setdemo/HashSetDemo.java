package com.infosys.enr.setdemo;

import java.util.HashSet;
import java.util.Iterator;

import com.infosys.enr.comparabledemo.Fresher;

public class HashSetDemo {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// ����һ��HashSet���϶���
		/*HashSet set = new HashSet();
		set.add("ok");
		set.add(100);
		set.add(10);
		set.add(200);
		set.add("smile");
		Fresher fresher = new Fresher();
		int i = 100;
		fresher.setFresherAge(100);
		String s = "ok";
		
		String ss = new String("ok");
		Iterator it = set.iterator();
		while (it.hasNext()) {
			Object obj = it.next();
			System.out.println(obj);
		}*/
		HashSet<Fresher> freshers = new HashSet<Fresher>();
		Fresher frsherFirst = new Fresher(20, 8, "James");
		Fresher frsherSec = new Fresher(10, 3, "Wade");
		Fresher frsherThird = new Fresher(40, 5, "DK");
		freshers.add(frsherFirst);
		freshers.add(frsherSec);
		freshers.add(frsherThird);
		Iterator<Fresher> it = freshers.iterator();
		while (it.hasNext()) {
			Fresher fresher = it.next();
			System.out.println(fresher);
		}
	}

}
