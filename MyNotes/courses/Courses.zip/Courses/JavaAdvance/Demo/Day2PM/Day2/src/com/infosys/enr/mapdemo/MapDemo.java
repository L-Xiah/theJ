package com.infosys.enr.mapdemo;

import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import com.infosys.enr.comparabledemo.Fresher;

public class MapDemo {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashMap<String, Fresher> map = new HashMap<String, Fresher>();
		Fresher fresherFirst = new Fresher(20, 8, "James");
		Fresher fresherSec = new Fresher(10, 3, "Wade");
		Fresher fresherThird = new Fresher(40, 5, "DK");
		// ���Ӽ�ֵ��
		map.put(fresherFirst.getFresherName(), fresherFirst);
		map.put(fresherSec.getFresherName(), fresherSec);
		map.put(fresherThird.getFresherName(), fresherThird);
		System.out.println(map.size());
		System.out.println(map.isEmpty());
		System.out.println(map.containsKey("James"));
		System.out.println(map.containsValue(fresherThird));
		// key�ļ���
		// Type mismatch: cannot convert from Set<String> to HashSet<String>
		Set<String> keys = map.keySet();
		Iterator<String> itKey = keys.iterator();
		while (itKey.hasNext()) {
			String key = itKey.next();
			Fresher fresher = map.get(key);
			System.out.println("key:" + key);
			System.out.println("Fresher's information shown as bellow:");
			System.out.println(fresher);
		}
		// value�ļ���
		Collection<Fresher> freshers = map.values();
		Iterator<Fresher> itFreshers = freshers.iterator();
		while (itFreshers.hasNext()) {
			Fresher fresher = itFreshers.next();
			System.out.println(fresher);
		}
		// Entry���͵ļ��ϣ�key-value���͵ļ��ϣ�
		Set<Map.Entry<String, Fresher>> pairs =  map.entrySet();
		Iterator<Map.Entry<String, Fresher>> items = pairs.iterator();
		while (items.hasNext()) {
			Map.Entry<String, Fresher> item = items.next();
			String key = item.getKey();
			Fresher fresher = item.getValue();
			System.out.println("key:" + key);
			System.out.println("Fresher's information shown as bellow:");
			System.out.println(fresher);
		}
	}

}
