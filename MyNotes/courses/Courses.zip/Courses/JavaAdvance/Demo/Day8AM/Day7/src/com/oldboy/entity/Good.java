package com.oldboy.entity;

public class Good {

	// goodId,goodName,goodPrice,goodBalance,goodDesc
	private int goodId;
	private String goodName;
	private double goodPrice;
	private int goodBalance;
	private String goodDesc;

	public int getGoodId() {
		return goodId;
	}

	public void setGoodId(int goodId) {
		this.goodId = goodId;
	}

	public String getGoodName() {
		return goodName;
	}

	public void setGoodName(String goodName) {
		this.goodName = goodName;
	}

	public double getGoodPrice() {
		return goodPrice;
	}

	public void setGoodPrice(double goodPrice) {
		this.goodPrice = goodPrice;
	}

	public int getGoodBalance() {
		return goodBalance;
	}

	public void setGoodBalance(int goodBalance) {
		this.goodBalance = goodBalance;
	}

	public String getGoodDesc() {
		return goodDesc;
	}

	public void setGoodDesc(String goodDesc) {
		this.goodDesc = goodDesc;
	}

	public Good(int goodId, String goodName, double goodPrice, int goodBalance,
			String goodDesc) {
		super();
		this.goodId = goodId;
		this.goodName = goodName;
		this.goodPrice = goodPrice;
		this.goodBalance = goodBalance;
		this.goodDesc = goodDesc;
	}
	public Good(String goodName, double goodPrice, int goodBalance,
			String goodDesc) {
		super();
		
		this.goodName = goodName;
		this.goodPrice = goodPrice;
		this.goodBalance = goodBalance;
		this.goodDesc = goodDesc;
	}
	public Good() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {

		return goodId + "\t" + goodName + "\t" + goodPrice + "\t" + goodBalance
				+ "\t" + goodDesc;
	}

}
