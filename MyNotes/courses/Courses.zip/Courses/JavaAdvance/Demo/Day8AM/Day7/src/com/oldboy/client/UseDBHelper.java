package com.oldboy.client;

import java.util.ArrayList;

import com.oldboy.dao.GoodDao;
import com.oldboy.entity.Good;

public class UseDBHelper {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		GoodDao goodDao = new GoodDao();
		ArrayList<Good> goods = goodDao.queryAllGoods();
		System.out.println(goods);
		/*Good good = goodDao.queryGoodByGoodId(1);
		System.out.println(good);*/
		/*Good good = new Good("Desk", 10000, 10, "Good" );
		boolean flag = goodDao.addGood(good);
		System.out.println(flag);*/
		Good good = new Good("Book", 10, 10000, "Good" );
		boolean flag = goodDao.addGood("Book", 10, 10000, "Good" );
		System.out.println(flag);
	}

}
