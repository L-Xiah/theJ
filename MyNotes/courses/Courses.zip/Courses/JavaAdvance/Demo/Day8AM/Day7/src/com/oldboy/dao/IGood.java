package com.oldboy.dao;

import java.util.ArrayList;

import com.oldboy.entity.Good;

public interface IGood {

	public ArrayList<Good> queryAllGoods();
	public Good queryGoodByGoodId(int goodId);
	public boolean modifyGoodBalance(Good good);
	public boolean deleteGoodByGoodId(int goodId);
	public boolean addGood(Good good);
	public boolean addGood(String goodName, double goodPrice, int goodBalance, String goodDesc);
}
