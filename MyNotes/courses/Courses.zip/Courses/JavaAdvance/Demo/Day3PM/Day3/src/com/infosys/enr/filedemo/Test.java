package com.infosys.enr.filedemo;

public class Test {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		FileManager.deleteFolder("data");
	}

}
