package com.infosys.enr.demo;

public class Demo {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Integer intValue = new Integer(100);
		System.out.println(intValue + 1);
		System.out.println(intValue.intValue());
		Character c = new Character('a');
		System.out.println(c.charValue());
		// ����ת��
		String s = intValue.toString();
		String str = String.valueOf(intValue);
		System.out.println(s + 1);
		System.out.println(intValue + 1);
		System.out.println(str + 1);
		String value = "123";
		int iv = Integer.valueOf(value);
		// Float.valueOf(value)
		System.out.println(iv + 1);
		Character.isDigit('1');
		Character.isLetter('a');
		Character.isWhitespace(' ');
	}

}
