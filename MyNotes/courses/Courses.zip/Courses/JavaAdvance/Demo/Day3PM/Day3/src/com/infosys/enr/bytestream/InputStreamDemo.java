package com.infosys.enr.bytestream;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;

public class InputStreamDemo {

	/**
	 * @param args
	 * @throws FileNotFoundException 
	 */
	public static void main(String[] args) {
		FileInputStream fis = null;
		byte[] cup = null;
		try {
			// 可能引发异常的语句
			fis = new FileInputStream("data\\a.txt");
			int n = -1;
			System.out.println(fis.available());
			cup = new byte[fis.available()];
			int i = 0;
			while((n = fis.read()) != -1) {

				// System.out.print((char)n);
				cup[i] = new Integer(n).byteValue();
				i++;
			}
	} catch (FileNotFoundException e) {
			// 捕获异常，并处理的语句
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			// 不管是否发生异常都会执行的语句
			try {
				fis.close();
				System.out.println(new String(cup));
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		
	}

}
