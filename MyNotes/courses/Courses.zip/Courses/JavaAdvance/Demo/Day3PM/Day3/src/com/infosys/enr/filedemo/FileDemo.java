package com.infosys.enr.filedemo;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;

public class FileDemo {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		File fileFirst = new File("D:\\B42\\JavaAdvance\\filedoc");
		File dataFile = new File("data");
	    File fileSec = new File("D:\\B42\\JavaAdvance\\filedoc\\a.txt");
	    System.out.println(fileFirst.isDirectory());
	    System.out.println(fileSec.isFile());
	    System.out.println(fileFirst.getName());
	    System.out.println(fileSec.getName());
	    System.out.println(fileFirst.getPath());
	    System.out.println(fileFirst.getAbsolutePath());
	    System.out.println(dataFile.getPath());
	    System.out.println(dataFile.getAbsolutePath());
	    
	    System.out.println(fileFirst.canRead());
	    System.out.println(fileFirst.canWrite());
	    System.out.println(fileFirst.canExecute());
	    System.out.println(fileFirst.exists());
	    System.out.println(fileFirst.getParent());
	    // 1��1000����
	    long time = dataFile.lastModified();
	    Date date = new Date();
	    date.setTime(time);
	    
	    System.out.println(time);
	    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	    String lastModifiedInfor = sdf.format(date);
	    System.out.println(lastModifiedInfor);
	    System.out.println(System.currentTimeMillis());
	    String[] fileNames = dataFile.list();
	    File[] subFiles =  dataFile.listFiles();
	    // dataFile.delete();
	    dataFile.mkdir();
	    File newFile = new File("scores");
	    dataFile.renameTo(newFile);
	}
}
