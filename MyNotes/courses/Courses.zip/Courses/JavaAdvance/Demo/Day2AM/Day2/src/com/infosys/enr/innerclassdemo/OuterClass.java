package com.infosys.enr.innerclassdemo;

public class OuterClass {

	private int value = 100;
	public int age = 30;
	public static int score = 88;
	
	public void outerMethod() {
		System.out.println(score);
	}
	public static void outerMethodStatic() {
		System.out.println(score);
		// Cannot make a static reference to the non-static field age
		// System.out.println(age);
	}
	public void testLocalInnerClass() {
		class LocalInnerClass {
			
			
		}
	}
	public class InnerClass {
		private int value = 200;
		public int result = 10;
		// The field ok cannot be declared static; static fields can only be declared in static or top level types
		// public static int ok = 99;
		public void queryValue() {
			System.out.println(age + "\t" + OuterClass.this.value + "\t" + value);
		}

	}

	public static class StaticInnerClass {
		private int count = 10;
		public int n = 1;
		public void staticMethodFirst() {
			// Cannot make a static reference to the non-static field age
			// System.out.println(age);
			System.out.println(score);
			outerMethodStatic();
			// Cannot make a static reference to the non-static method outerMethod() from the type OuterClass
			// outerMethod();
		}

	}
	
}