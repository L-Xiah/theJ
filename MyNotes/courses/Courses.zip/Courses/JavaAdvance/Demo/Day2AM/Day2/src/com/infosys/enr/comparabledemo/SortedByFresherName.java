package com.infosys.enr.comparabledemo;

import java.util.Comparator;

public class SortedByFresherName implements Comparator<Fresher> {

	@Override
	public int compare(Fresher o1, Fresher o2) {
		if (o1.getFresherName().compareTo(o2.getFresherName()) > 0) {
			return 1;
		} else if (o1.getFresherName().compareTo(o2.getFresherName()) < 0) {
			return -1;
		} else {
			return 0;
		}
	}

}
