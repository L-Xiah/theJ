package com.oldboy.fm.entity;

import java.io.Serializable;

public class Fresher implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	// Fresher(id,name,pwd,age,tel,level,salary,score)
	private String id;
	private String name;
	private String pwd;
	private int age;
	private String tel;
	private String level;
	private double salary;
	private int score;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPwd() {
		return pwd;
	}

	public void setPwd(String pwd) {
		this.pwd = pwd;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getTel() {
		return tel;
	}

	public void setTel(String tel) {
		this.tel = tel;
	}

	public String getLevel() {
		return level;
	}

	public void setLevel(String level) {
		this.level = level;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public int getScore() {
		return score;
	}

	public void setScore(int score) {
		this.score = score;
	}

	public Fresher(String id, String name, String pwd, int age, String tel,
			String level, double salary, int score) {
		super();
		this.id = id;
		this.name = name;
		this.pwd = pwd;
		this.age = age;
		this.tel = tel;
		this.level = level;
		this.salary = salary;
		this.score = score;
	}

	public Fresher() {
		super();

	}

	@Override
	public String toString() {

		return id + "\t" + name + "\t" + pwd + "\t" + age + "\t" + tel + "\t"
				+ level + "\t" + salary + "\t" + score;
	}

}
