package com.oldboy.fm.controller;

import java.util.HashMap;
import java.util.Scanner;

import com.oldboy.fm.view.View;

public abstract class Controller {
	public Scanner input = new Scanner(System.in);
	private HashMap bag = new HashMap();
    private View nextView = null;
    
	public Scanner getInput() {
		return input;
	}

	public void setInput(Scanner input) {
		this.input = input;
	}

	public HashMap getBag() {
		return bag;
	}

	public void setBag(HashMap bag) {
		this.bag = bag;
	}

	public View getNextView() {
		return nextView;
	}

	public void setNextView(View nextView) {
		this.nextView = nextView;
	}


	public abstract View handle(View view);
}
