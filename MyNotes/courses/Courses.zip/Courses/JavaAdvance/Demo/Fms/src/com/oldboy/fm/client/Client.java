package com.oldboy.fm.client;

import com.oldboy.fm.view.MainMenuView;
import com.oldboy.fm.view.View;

public class Client {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// �������˵���ͼ
		View view = new MainMenuView();
		while(view != null) {
			view = view.show();
		}

	}

}
