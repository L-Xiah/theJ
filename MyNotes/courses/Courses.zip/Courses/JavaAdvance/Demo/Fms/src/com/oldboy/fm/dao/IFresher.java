package com.oldboy.fm.dao;

import java.util.ArrayList;

import com.oldboy.fm.entity.Fresher;

public interface IFresher {

	public ArrayList<Fresher> queryAllFreshers();
	public Fresher queryFresherById(String id);
	public boolean regiserFresher(Fresher fresher);
	public boolean deleteFresherById(String id);
}
