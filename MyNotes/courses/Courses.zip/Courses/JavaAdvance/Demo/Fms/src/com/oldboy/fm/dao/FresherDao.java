package com.oldboy.fm.dao;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

import com.oldboy.fm.entity.Fresher;

public class FresherDao implements IFresher {

	public static void main(String[] args) {
		FresherDao dao = new FresherDao();
		
	}
	@Override
	public ArrayList<Fresher> queryAllFreshers() {
		// ��ȡ��Ԫ����Դ�е���Ϣ������Դ��data\freshers.dat����д��Ϣʱ���������л������л�ʵ�֣�
		FileInputStream fis = null;
		ObjectInputStream ois = null;
		ArrayList<Fresher> freshers = null;
	
		try {
			fis = new FileInputStream("data\\employee.dat");
			ois = new ObjectInputStream(fis);
			// ͨ��ois������
			Object tempObj = null;
			while ((tempObj = ois.readObject()) != null) {
				freshers = (ArrayList<Fresher>)tempObj;
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			
		} catch (ClassNotFoundException e) {
			System.out.println("�״�ʹ�ã����ģ��Ͻ��ðɣ�");
		} finally {
			if (fis != null && ois != null) {
				try {
					fis.close();
					ois.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			}
		}
		
		return freshers;
	}

	@Override
	public Fresher queryFresherById(String id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean regiserFresher(Fresher fresher) {
		boolean flag = true;
		
		FileOutputStream fos = null;
		ObjectOutputStream oos = null;
		// ���ò�ѯ����
		ArrayList<Fresher> freshers = queryAllFreshers();
		try {
			if (freshers != null) {
				// �������ӵ�ϵͳ��fresher�������ӵ�����
				freshers.add(fresher);
			} else {
				freshers = new ArrayList<Fresher>();
				freshers.add(fresher);
			}
			// ������һ�������л�������data\\freshers.dat�ļ�
			// ����һ��ObjectOutputStream����
			fos = new FileOutputStream("data\\employee.dat");
			oos = new ObjectOutputStream(fos);
			oos.writeObject(freshers);
			
		} catch (FileNotFoundException e) {
			flag = false;
			
		} catch (IOException e) {
			
		} finally {
			if (fos != null && oos != null) {
				try {
					
					oos.close();
					fos.close();
				} catch (IOException e) {
					flag = false;
					e.printStackTrace();
				}
				
				
			}
		}
		
		return flag;
	}

	@Override
	public boolean deleteFresherById(String id) {
		// TODO Auto-generated method stub
		return false;
	}

}
