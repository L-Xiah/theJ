package com.oldboy.fm.entity;

public class Trainer {
	
	private String id;
	private String name;
	private String pwd;
	private int age;
	private String tel;
	private String level;
	private int teachYears;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getTel() {
		return tel;
	}
	public void setTel(String tel) {
		this.tel = tel;
	}
	public String getLevel() {
		return level;
	}
	public void setLevel(String level) {
		this.level = level;
	}
	public int getTeachYears() {
		return teachYears;
	}
	public void setTeachYears(int teachYears) {
		this.teachYears = teachYears;
	}
	public Trainer(String id, String name, String pwd, int age, String tel,
			String level, int teachYears) {
		super();
		this.id = id;
		this.name = name;
		this.pwd = pwd;
		this.age = age;
		this.tel = tel;
		this.level = level;
		this.teachYears = teachYears;
	}
	public Trainer() {
		super();
		
	}
	@Override
	public String toString() {
		
		return id + "\t" + name + "\t" + pwd + "\t" + age + "\t" + tel + "\t"
				+ level + "\t" + teachYears;
	}
}
