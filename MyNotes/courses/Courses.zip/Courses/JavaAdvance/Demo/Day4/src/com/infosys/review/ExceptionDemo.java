package com.infosys.review;

import java.util.IllegalFormatException;
import java.util.InputMismatchException;
import java.util.Scanner;

public class ExceptionDemo {

	public static int divide(int number1, int number2)
			throws ArithmeticException, NullPointerException {
		int result = 0;
		try {

			result = number1 / number2;
			System.out.println("ok");
		} catch (ArithmeticException e) {
			System.out.println("error");
			e.printStackTrace();
		} catch (Exception e) {
			System.out.println("error");
			e.printStackTrace();
			// Unreachable catch block for ArithmeticException. It is already
			// handled by the catch block for Exception
		} finally {
			System.out.println("Finally");
		}
		return result;
	}

	public static int addition() {
		int num1 = 0;
		int num2 = 0;
		boolean flag = true;
		while (flag) {
			try {
				Scanner input = new Scanner(System.in);
				System.out.println("Please input an integer number1:");
				num1 = input.nextInt();
				System.out.println("Please input an integer number2:");
				num2 = input.nextInt();
				flag = false;

			} catch (InputMismatchException e) {
				System.out.println("Try agin!");
				continue;
			}
		}

		return num1 + num2;
	}

	public static boolean checkPwdLength(String password)
			throws NullPointerException, CheckPwdException {
		if (password == null) {
			throw new NullPointerException();
		} else {
			if (password.length() < 6) {
				throw new CheckPwdException("The password length is less than 6!");
			} else {
				return true;
			}
		}
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		/*
		 * try { ExceptionDemo.divide(10, 0); } catch (ArithmeticException e) {
		 * // TODO Auto-generated catch block e.printStackTrace(); } catch
		 * (NullPointerException e) { // TODO Auto-generated catch block
		 * e.printStackTrace(); }
		 */
		// System.out.println(ExceptionDemo.addition());
		try {
			checkPwdLength("James");
		} catch (NullPointerException e) {
			System.out.println("NullpointerException");
		} catch (CheckPwdException e) {
			System.out.println(e.getWarningInfor());
		}
	}

}
