package com.infosys.review;

public class ParseStringToByteArray {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		String content = "Today is so hot!";
		byte[] array = content.getBytes();
		for (byte i : array) {
			System.out.println(i);
		}
		char[] arrayChars = content.toCharArray();
		for (char c : arrayChars) {
			System.out.print(c);
		}
		char[] arrayTempChars = new char[] {'a', 'b', 'c'};
	    String s = new String(arrayTempChars);
	    System.out.println(s);
	}

}
