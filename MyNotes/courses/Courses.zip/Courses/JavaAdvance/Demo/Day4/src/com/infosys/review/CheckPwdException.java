package com.infosys.review;

public class CheckPwdException extends Exception {

	private String warningInfor = "";

	public String getWarningInfor() {
		return warningInfor;
	}

	public void setWarningInfor(String warningInfor) {
		this.warningInfor = warningInfor;
	}

	public CheckPwdException(String warningInfor) {
		super();
		this.warningInfor = warningInfor;
	}

	public CheckPwdException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CheckPwdException(String message, Throwable cause,
			boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public CheckPwdException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public CheckPwdException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}
	
}
