﻿public boolean addGood(Good good) {
		int count = 0;
		// 米¯車?∩?∩⊿1y3足㏒?那米??谷足?﹞米?足赤?車
		
		// 足赤?車谷足?﹞米?∩?∩⊿1y3足proc_addgood
		
		// ??米?辰????谷辰?芍??車米?那y?Y?a米?芍??車???車
		Connection con = DBHelper.getConnection();
		// 角?車?芍??車那y?Y?a???車㏒?∩∩?“辰????谷辰?2迄℅¯那y?Y?a米????車㏒“米¯車?∩?∩⊿1y3足㏒?
		CallableStatement cs = null;
		try {
			cs = con.prepareCall("{ call proc_addgood(?,?,?,?,?)}");
			// goodName,goodPrice,goodBalance,goodDesc,addstatus
			// ?迆?∩DD∩?∩⊿1y3足???～㏒???2?那y足赤?車??角∩
			cs.setString(1, good.getGoodName());
			cs.setDouble(2, good.getGoodPrice());
			cs.setInt(3, good.getGoodBalance());
			cs.setString(4, good.getGoodDesc());
			// ??車迆那?3?2?那y米??3?米㊣豕??足?那a
			cs.registerOutParameter(5, Types.INTEGER);
			// ?∩DD∩?∩⊿1y3足
			cs.execute();
			// 赤“1yCallableStatement???車??米?﹞米???米
			 count = cs.getInt(5);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return count > 0 ? true : false;
	}

	@Override
	public boolean addGood(String goodName, double goodPrice, int goodBalance,
			String goodDesc) {
		int count = 0;
		// 米¯車?∩?∩⊿1y3足㏒?那米??谷足?﹞米?足赤?車
		
		// 足赤?車谷足?﹞米?∩?∩⊿1y3足proc_addgood
		
		// ??米?辰????谷辰?芍??車米?那y?Y?a米?芍??車???車
		Connection con = DBHelper.getConnection();
		// 角?車?芍??車那y?Y?a???車㏒?∩∩?“辰????谷辰?2迄℅¯那y?Y?a米????車㏒“米¯車?∩?∩⊿1y3足㏒?
		CallableStatement cs = null;
		try {
			cs = con.prepareCall("{ ? = call fun_addgood(?,?,?,?)}");
			// goodName,goodPrice,goodBalance,goodDesc,addstatus
			// ?迆?∩DD∩?∩⊿1y3足???～㏒???2?那y足赤?車??角∩
			cs.setString(2, goodName);
			cs.setDouble(3, goodPrice);
			cs.setInt(4, goodBalance);
			cs.setString(5, goodDesc);
			// ??車迆那?3?2?那y米??3?米㊣豕??足?那a
			cs.registerOutParameter(1, Types.INTEGER);
			// ?∩DD∩?∩⊿1y3足
			cs.execute();
			// 赤“1yCallableStatement???車??米?﹞米???米
			 count = cs.getInt(1);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return count > 0 ? true : false;
	}

}