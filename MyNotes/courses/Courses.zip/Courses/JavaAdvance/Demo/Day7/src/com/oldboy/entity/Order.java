package com.oldboy.entity;

public class Order {

	// orderId,orderOwner,orderTotail,orderStatus
	private int orderId;
	private String orderOwner;
	private double orderTotail;
	private String orderStatus;

	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	public String getOrderOwner() {
		return orderOwner;
	}

	public void setOrderOwner(String orderOwner) {
		this.orderOwner = orderOwner;
	}

	public double getOrderTotail() {
		return orderTotail;
	}

	public void setOrderTotail(double orderTotail) {
		this.orderTotail = orderTotail;
	}

	public String getOrderStatus() {
		return orderStatus;
	}

	public void setOrderStatus(String orderStatus) {
		this.orderStatus = orderStatus;
	}

	public Order(int orderId, String orderOwner, double orderTotail,
			String orderStatus) {
		super();
		this.orderId = orderId;
		this.orderOwner = orderOwner;
		this.orderTotail = orderTotail;
		this.orderStatus = orderStatus;
	}

	public Order() {
		super();

	}

	@Override
	public String toString() {

		return "orderId:" + orderId + "\torderOwner:" + orderOwner
				+ "\torderTotail:" + orderTotail + "\torderStatus:"
				+ orderStatus;
	}
}
