package com.oldboy.entity;

public class OrderIterm {

	// orderItermId,orderId,goodId,goodCount
	private int orderItermId;
	private int orderId;
	private int goodId;
	private int goodCount;
	public int getOrderItermId() {
		return orderItermId;
	}
	public void setOrderItermId(int orderItermId) {
		this.orderItermId = orderItermId;
	}
	public int getOrderId() {
		return orderId;
	}
	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}
	public int getGoodId() {
		return goodId;
	}
	public void setGoodId(int goodId) {
		this.goodId = goodId;
	}
	public int getGoodCount() {
		return goodCount;
	}
	public void setGoodCount(int goodCount) {
		this.goodCount = goodCount;
	}
	public OrderIterm(int orderItermId, int orderId, int goodId, int goodCount) {
		super();
		this.orderItermId = orderItermId;
		this.orderId = orderId;
		this.goodId = goodId;
		this.goodCount = goodCount;
	}
	public OrderIterm() {
		super();
		// TODO Auto-generated constructor stub
	}
	
}
