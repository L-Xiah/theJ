package com.infosys.bufferreadandwrite;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class BufferedReaderDemo {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// ��׼��һ��ֱ����������Դ���ַ�����������
		FileReader reader = null;
		BufferedReader br = null;
		try {
			reader = new FileReader("data\\d.txt");
			// BufferedReader���ַ��������Ľڵ�������
			br = new BufferedReader(reader);
			String row = null;
			while ((row = br.readLine()) != null) {
				System.out.println(row);
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if (reader != null && br != null) {
				try {
					reader.close();
					br.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			}
		}
		

	}

}
