package com.infosys.outputstreamdemo;

import java.io.OutputStream;

public class OutputStreamDemo {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		OutputStream ops;

	}

}
