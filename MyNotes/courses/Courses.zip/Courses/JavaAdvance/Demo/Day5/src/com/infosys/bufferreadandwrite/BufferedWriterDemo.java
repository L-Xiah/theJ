package com.infosys.bufferreadandwrite;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class BufferedWriterDemo {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		FileWriter writer = null;
		BufferedWriter bw = null;
		try {
			writer = new FileWriter("data\\d.txt", true);
			bw = new BufferedWriter(writer);
			bw.write("\n֪������֪��������֪����");
			bw.newLine();
			bw.write("֪������֪��������֪����");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if (writer != null && bw != null) {
				try {
					bw.close();
					writer.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			}
		}
		

	}

}
