imp Oracleusername/password@hoststring
tables=(LOGIN,CUSTOMER,ACCOUNT,TRANSACTION)
//
Import: Release 9.0.1.1.1 - Production on Wed Mar 30 09:43:41 2005
(c) Copyright 2001 Oracle Corporation. All rights reserved.
Connected to: Oracle9i Enterprise Edition Release 9.0.1.1.1 -
Production
With the Partitioning option
JServer Release 9.0.1.1.1 - Production
IMP-00002: failed to open EXPDAT.DMP for read
Import file: EXPDAT.DMP >
//
Export file created by EXPORT:V10.01.00 via conventional path
import done in WE8MSWIN1252 character set and AL16UTF16 NCHAR
character set
. importing SCOTT's objects into SCOTT
. . importing table "LOGIN" 3 rows
imported
. . importing table "CUSTOMER" 3 rows
imported
. . importing table "ACCOUNT" 5 rows
imported
. . importing table "TRANSACTION" 6 rows
imported
Import terminated successfully without warnings.
Select * from CUSTOMER;