create or replace trigger trigger_example
after insert on employee
begin
dbms_output.put_line('Data Inserted into the Employee Table
successfully');
end;
//
insert into employee values (1070, 'noname', 10000, 'A');
