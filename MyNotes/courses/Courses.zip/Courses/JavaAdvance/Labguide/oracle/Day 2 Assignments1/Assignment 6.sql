CREATE OR REPLACE PACKAGE outputPackage
IS
PROCEDURE add(val IN NUMBER,val2 IN NUMBER);
PROCEDURE add(val IN VARCHAR2,val2 IN VARCHAR2);
END outputPackage;
//
CREATE OR REPLACE PACKAGE BODY outputPackage
IS
PROCEDURE add(val IN NUMBER,val2 IN NUMBER) IS
BEGIN
--display the calculation result
DBMS_OUTPUT.put_line(TO_CHAR (val+val2));
END;
PROCEDURE add(val IN VARCHAR2,val2 IN VARCHAR2) IS
BEGIN
--display the concatenated value
DBMS_OUTPUT.put_line(TO_CHAR (val||val2));
END;
END outputPackage;
//
BEGIN
outputPackage.add(2,3);
outputPackage.add('Hi','World');
END;
//
