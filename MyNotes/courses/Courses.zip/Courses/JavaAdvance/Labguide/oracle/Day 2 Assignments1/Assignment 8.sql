exp OracleUserName/password@hostname file=accountsbackup.expdat
tables=(LOGIN,CUSTOMER,ACCOUNT,TRANSACTION) log=accountsbackup.log
//
Export: Release 9.0.1.1.1 - Production on Wed Mar 30 09:32:23 2005
(c) Copyright 2001 Oracle Corporation. All rights reserved.
Connected to: Oracle9i Enterprise Edition Release 9.0.1.1.1 -
Production
With the Partitioning option
JServer Release 9.0.1.1.1 - Production
Export done in WE8MSWIN1252 character set and AL16UTF16 NCHAR
character set
About to export specified tables via Conventional Path ...
. . exporting table LOGIN 3 rows
exported
. . exporting table CUSTOMER 3 rows
exported
. . exporting table ACCOUNT 5 rows
exported
. . exporting table TRANSACTION 6 rows
exported
Export terminated successfully without warnings.
//