LOAD DATA
INFILE 'E:\workarea\contestwinners.csv'
REPLACE
INTO TABLE scott.contest_winners
FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '"'
TRAILING NULLCOLS
(userid INTEGER EXTERNAL,
averageRating DECIMAL EXTERNAL,
dateOfWinning DATE
)
//
create table contest_winners(
userid number,
averageRating number(5,2),
dateOfWinning DATE);
//
sqlldr OracleUserName/Password@Hostname
control=e:\workarea\contest.ctl
SQL*Loader: Release 9.0.1.1.1 - Production on Wed Mar 30 10:07:11 2005
(c) Copyright 2001 Oracle Corporation. All rights reserved.
Commit point reached - logical record count 10
Select * from contest_winners;
//
create table test(
stuno number(2) primary key,
stuname varchar2(10) not null,
stuage number(2) not null
)
create table test_log(
stuLog varchar2(10) primary key,
stuname varchar2(10) references test(stuname),
stupsw number(2)
startDate date not null,
endDate date not null
)
create or replace trigger trigger_name
before insert on test_log
for each row
begin
if :new.startDate <= :new.endDate then
				raise_application_error('mistakes');
end if;
end;


//
CREATE OR REPLACE TRIGGER authorization
BEFORE INSERT OR DELETE OR UPDATE ON employee
DECLARE
v_user varchar2(50);
BEGIN
SELECT USER into v_user FROM dual;
IF v_user = 'TRNG' THEN
RAISE_APPLICATION_ERROR(-20001,'You are not an authorized user');
END IF;
END;
//
CREATE OR REPLACE TRIGGER checklocation AFTER INSERT ON employee
FOR EACH ROW
BEGIN
:NEW.location := 'Bangalore';
END;
//
CREATE OR REPLACE TRIGGER statusupdate AFTER UPDATE OF status on projects
FOR EACH ROW
BEGIN
IF :NEW.status = 'Completed' THEN
UPDATE employee set employee.projectcode = NULL WHERE
employee.projectcode = :NEW.projectcode;
END IF;
END;
//
CREATE OR REPLACE TRIGGER checkbalance BEFORE UPDATE OR INSERT on account
FOR EACH ROW
BEGIN
IF INSERTING THEN
IF :NEW.balance < 5000 THEN
RAISE_APPLICATION_ERROR(-20001,'Inital balance cannot be less than 5000');
END IF;
ELSE
IF :NEW.balance < 1000 THEN
RAISE_APPLICATION_ERROR(-20002,'Balance cannot be less than 1000');
END IF;
END;
//
CREATE OR REPLACE PACKAGE MyPack
IS
FUNCTION sqr(x IN number) RETURN number;
FUNCTION cube(x IN number)RETURN number;
END;
CREATE OR REPLACE PACKAGE BODY MyPack
IS
FUNCTION sqr(x IN number) RETURN number
IS
BEGIN
RETURN (X*X);
END;
FUNCTION cube(x IN number) RETURN number
IS
BEGIN
RETURN (X*X*x);
END;
END;
SELECT Mypack.sqr(5) FROM dual;
SELECT Mypack.cube(2) FROM dual;


























