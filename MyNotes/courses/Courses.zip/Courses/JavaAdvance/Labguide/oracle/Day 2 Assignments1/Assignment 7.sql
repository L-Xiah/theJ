create table AccountLog(
ClosedBy varchar2(20),
ClosedOn date
)
create or replace trigger tri_stuInfo
		before insert or delele or update
		on AccountLog
		begin
			if(
     			(to_char(sysdate,'HH24:MI')not between '08:30'and'18:00') then
				raise_application_error(-20001,'not working time,cannot make any change on AccountLog');
			end if;
		end;
create table HEFTY_TRANSACTIONS(
customerName VARCHAR2(25),
accountNumber NUMBER(4),
amountOfTransaction NUMBER(9,2)
)
create or replace trigger Account
		before insert or delele or update
		on HEFTY_TRANSACTIONS
		begin
			if accountNumber>=200000 or amountOfTransaction>=100000then
				raise_application_error(-20001,'not working time,cannot make any change on AccountLog');
			end if;
		end;