create or  replace  procedure sp_Get_Grade( p_eNo in EMPLOYEE.EmpNo%type:=0 , p_eGrade OUT EMPLOYEE.Grade%type) is
begin
select grade into p_eGrade from employee where EmpNo = p_eNo;
exception
when NO_DATA_FOUND then
p_eGrade := 'Z';
when others then
p_eGrade :='Z';
dbms_output.put_line('*** Error occurred ***');
dbms_output.put_line('SQLCODE: '||to_char(sqlcode));
dbms_output.put_line('SQLERRM: '||sqlerrm);
end;
//
declare
v_employeeNo EMPLOYEE.EmpNo%type;
v_employeeGrade EMPLOYEE.Grade%type;
begin
v_employeeNo :=1;
sp_Get_Grade(v_employeeNo, v_employeeGrade);
if v_employeeGrade = 'Z' then
dbms_output.put_line('Employee No Not Found');
else
dbms_output.put_line('Employee Grade is '||v_employeeGrade);
end if;
exception 
when others then
dbms_output.put_line('*** Error occurred ***');
dbms_output.put_line('SQLCODE: '||to_char(sqlcode));
dbms_output.put_line('SQLERRM: '||sqlerrm);
end;













