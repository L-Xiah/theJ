Create table employee (
empNo number,
empName varchar2(20),
empSalary number(8,2),
grade char(1)
);
