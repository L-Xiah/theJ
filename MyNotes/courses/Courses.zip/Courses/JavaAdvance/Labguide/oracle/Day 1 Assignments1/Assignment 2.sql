create  table Login(
UserID Varchar2(8) Primary Key,
Password Varchar2(20) Not null,
Role Char(1) not null check (Role='Manager' or Role='Customer' or Role='Staff')
)
//
create table customer(
CustomerID Number(5) Primary Key,
UserID Varchar2(8) ,
Name Varchar2(25)  Not null,
Gender Char(1) check(Gender='Male' or Gender='Female'),
DateOfBirth Date,
Address Varchar2(30),
City Varchar2(10),
State Varchar2(10),
Pin Number(6),
Telephone Number(12),
Fax Number(12),
Email Varchar2(30)
)
//
create table Account(
AccountNo Number(4) Primary Key,
CustomerID Number(5) references customer(CustomerID),
AccountType Char(1) not null check(AccountType='S' or AccountType='Fixed ' or AccountType='C'),
DateOfOpening Date Not null,
DateOfMaturity Date check(Savings Account=null and Current
Account(C)=null),
CurrentBalance Number(9,2) not null check(CurrentBalance>=10000),
Status Char(1) not null check(Status='C' or Status='F')
)
//
create table Transaction(
TransactionID Number(7) Primary Key,
AccountNo Number(12) references Account(AccountNo),
DateOfTransaction Date,
Amount Number(9,2),
TransactionType Char(1) check(TransactionType='D'or TransactionType='W'),
Description Varchar2(25)
)
//
create sequence TransactionID
			increment by 1
			start with 1
			maxvalue 100
			nocycle
			cache 100;

//
insert into Login values('Jo01Jo','pass1','C');
insert into Login values('Tom2To','pass2','M');
insert into Login values('Jess33ca','pass3','S');
//
insert into customer values('10001','Jo01Jo','John','Male',to_date('1979-11-25','yyyy-mm-dd'),'#113, x-block','Bangalore','India',123456,081-57123451,null,'john@nyus.co.us');
insert into Customer values('10002','Tom2To','Tom Cruise','Male',to_date('1972-07-29','yyyy-mm-dd'),'#028, k-block','Mysore','India',567890,987654765,112-234-555,'tom@yahoo.com');
insert into Customer values('10003','Jess33ca','Jessica','Female',to_date('1982-01-19','yyyy-mm-dd'),'#1021, yk-block','Mysore','India',567890,0821-9876543,null,'jessica@mecus.co.us');
//
insert into Account values(2000,10002,'C',to_date('2009-01-12','yyyy-mm-dd'),null,40000,'C');
insert into Account values(2001,10001,'S',to_date('2009-01-12','yyyy-mm-dd'),null,42936,'F');
insert into Account values(2002,10003,'S',to_date('2009-03-13','yyyy-mm-dd'),null,10000,'F');
insert into Account values(2003,10002,'F',to_date('2009-03-13','yyyy-mm-dd'),to_date('2013-03-13','yyyy-mm-dd'),500000,'F');
insert into Account values(2004,10001,'S',to_date('2009-05-12','yyyy-mm-dd'),null,53000,'F');
//
insert into Transaction values(7000000,2000,to_date('2005-07-12','yyyy-mm-dd'),5000,'D','From Tom');
insert into Transaction values(7000001,2001,to_date('2005-07-12','yyyy-mm-dd'),500,'D','Self');
insert into Transaction values(7000002,2001,to_date('2005-07-13','yyyy-mm-dd'),1500,'D','Self');
insert into Transaction values(7000003,2002,to_date('2005-07-13','yyyy-mm-dd'),1500,'W','From jack');
insert into Transaction values(7000004,2002,to_date('2005-07-13','yyyy-mm-dd'),3500,'D','From Tim');
insert into Transaction values(7000005,2001,to_date('2005-07-13','yyyy-mm-dd'),1500,'W','Self');
//
create sequence seq_transationid
      increment by 1
	  start with 7000005
	  maxvalue 10000000000
	  nocycle
	  cache 100;
//
create or replace procedure store(
newAccountNo in number,
newAmount in number,
newTransactionType in char,
newDescription in varchar2
)
as
--局部变量定义区
pstuAccountNo number(4);
pstuAmount Nonumber(9,2);
pstuAmoun Char(1);
pstuDescription  Varchar2(25);
begin
select AccountNo,Amount,TransactionType,Description into pstuAccountNo,pstuAmount,pstuTransactionType,pstuDescription from Transaction;
	if pstuAccountNo<>null  and pstuAmount>0 and (pstuTransactionType='D' orpstuTransactionType='W') then
	insert into Transaction(AccountNo,Amount,TransactionType,Description)
	values(newAccountNo,newAmount,newTransactionType,newDescription);
	--end if;
	elsif pstuAccountNo=null then 
	return -1;
	elsif  pstuAmount<0 then 
	return -2;
	elsif pstuTransactionType!='D' or pstuTransactionType!='W'
	return -5;
	else
	dbms_output.put_line("transaction is successful.");
	end if;
	end store;

//
create or replace procedure  FindProjectCode(p_empid in employee.empid%type,
p_projectCode out employee.projectcode%type)
is
begin
select projectcode into p_projectcode from employee where
employee.empid = p_empid;
exception
when NO_DATA_FOUND then
p_projectCode := 'Z';
end;

//
--PL/SQL block to invoke the stored procedure
declare
v_projectcode employee.projectcode%type;
begin 
FindProjectCode(102,v_projectcode);
if v_projectcode = 'Z' then
dbms_output.put_line('Invalid Employee Id');
else
dbms_output.put_line(v_projectcode);
end if;
end;
//
--PL/SQL block to invoke the stored procedure
declare
v_projectcode employee.projectcode%type;
begin
FindProjectCode(106,v_projectcode);
if v_projectcode = 'Z' then
Dbms_output.put_line('Invalid Employee Id');
else
dbms_output.put_line(v_projectcode);
end if;
end;
//
create or replace function OvertimeEmployeeCount (p_projectCode in
employee.projectcode%type)
return  number
is
v_overtimecount number;
begin
select  count(overtimehours) into v_overtimecount
from employee where projectcode = p_projectcode;
return v_overtimecount;
end;

select  OvertimeEmployeeCount('p1') from dual;
//
create or replace function Myproc(p1 in number, p2 out number,
p3 inout number)
is
begin
p2 := p1 + p3;
p3 := p3 +10;
p1 :=78;
end;
declare
v1 number := 5;
v2 number;
v3 number:=10;
begin
Myproc(v1,v2,v3);
dbms_output.put_line(v1||' '||v2||' '||v3);
end;
begin
Myproc(10,20,40);
end;
//
create or replace procedure  Myproc(p1 in number default 1,
p2 in number default 2)
is 
v1 number;
begin
v1:= p1 + p2;
dbms_output.put_line(v1);
end;
//
Myproc(10,20);
Myproc;
Myproc(100);
Myproc(p2=>10);
//









































