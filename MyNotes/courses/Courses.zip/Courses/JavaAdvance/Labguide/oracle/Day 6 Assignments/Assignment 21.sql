create or replace view view_emp
as
select Branch name,count(*) from Student group by StudentId;
//
create or replace view view_emp1
as
select BranchName,CourseName from Branch,Course 
where Branch.BranchId=Course.BranchId;
//
create or replace view view_emp2
as 
select Roomno  from Hostel,Student
where Hostel.StudentId =Student.StudentId;
//
create or replace view view_emp3
as 
select CourseName,grade, sum(project marks + assignment marks + internal marks +
semester marks) as Total from Registration,Course,Student
where Registration.StudentId=Student.StudentId and Course.CourseId= Registration.CourseId;
//
create or replace view view_emp4
as 
select InstructorName,DepartmentName from Department,Instructor
where Department.DepartmentId =Instructor.DepartmentId ;