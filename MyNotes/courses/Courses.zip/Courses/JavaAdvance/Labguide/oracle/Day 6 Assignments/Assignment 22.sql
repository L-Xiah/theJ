create table BatchDetails(
BatchID Varchar2(10) Primary Key,
SectionID Char(1) Primary Key check(SectionID='A' or SectionID='B' or SectionID='C'),
BatchStream Varchar2(7) check(BatchStream='GENERIC'or BatchStream='OS'or BatchStream='.NET' or BatchStream='J2EE'),
BatchSize Number(3) check (BatchSize between 0 and 210)
)
//
insert into BatchDetails values('Jan05LC1','B','OS',150);
insert into BatchDetails values('Jan05LC1','C','MF',200);
insert into BatchDetails values('Feb05LC1','A','.NET',210);
insert into BatchDetails values('FEB05LC1','B','J2EE',150);
insert into BatchDetails values('MAR05LC1','A','GENERIC',100);
//
create table TraineeDetails(
TraineeID Varchar2(10) unique not null,
TraineeName Varchar2(25),
BatchID Varchar2(10) unique,
SectionID Char(1) unique
)
//
insert into TraineeDetails values('T0001','John','Jan08LC1','B');
insert into TraineeDetails values('T0002','Mary','Jan08LC1','C');
insert into TraineeDetails values('T0003','Simon','Jan08LC1','C');
insert into TraineeDetails values('T0004','Ema','FEB08LC1','B');
insert into TraineeDetails values('T0005','Henry','FEB08LC1','B');
insert into TraineeDetails values('T0006','Susan','FEB08LC1','A');
insert into TraineeDetails values('T0007','Laurel','FEB08LC1','A');
insert into TraineeDetails values('T0008','Nikhil','FEB08LC1','B');
insert into TraineeDetails values('T0009','Mike','FEB08LC1','B');
//
create table CourseDetails(
CourseID Varchar2(2) unique not null,
CourseName Varchar2(25),
Duration Number(2) check(Duration>21),
Prerequisite Varchar2(2) check(Prerequisite<>null)
)
//
insert into CourseDetails values('C1','Problem Solving',2,'null');
insert into CourseDetails values('C2','PF',4,'C1');
insert into CourseDetails values('C3','RDBMS',7,'C2');
insert into CourseDetails values('C4','SDM-UID',2,'C3');
insert into CourseDetails values('C5','OOC',1,'C4');
//
create table CourseOfferingDetails(
CourseID Varchar2(2) check(CourseID<>null),
TraineeID Varchar2(10) check(TraineeID<>null),
Marks Number(3) check(Marks>100)
)
//
insert into CourseOfferingDetails values('C1','T0001',89)
insert into CourseOfferingDetails values('C2','T0001',77)
insert into CourseOfferingDetails values('C3','T0001',98)
insert into CourseOfferingDetails values('C4','T0001',76)
insert into CourseOfferingDetails values('C1','T0002',98)
insert into CourseOfferingDetails values('C2','T0002',56)
insert into CourseOfferingDetails values('C3','T0002',79)
insert into CourseOfferingDetails values('C1','T0003',100)
insert into CourseOfferingDetails values('C2','T0003',97)
insert into CourseOfferingDetails values('C3','T0003',67)
insert into CourseOfferingDetails values('C1','T0004',56)
insert into CourseOfferingDetails values('C2','T0004',56)
insert into CourseOfferingDetails values('C1','T0005',89)
insert into CourseOfferingDetails values('C1','T0006',89)
insert into CourseOfferingDetails values('C1','T0007',89)
insert into CourseOfferingDetails values('C1','T0008',89)
insert into CourseOfferingDetails values('C1','T0009',89)
insert into CourseOfferingDetails values('C5','T0001',76)
//
select * from CourseDetails,TraineeDetails,CourseOfferingDetails where CourseDetails.CourseID=CourseOfferingDetails.CourseID
and TraineeDetails.TraineeID=CourseOfferingDetails.TraineeID;
//
select * from TraineeDetails,BatchDetails where TraineeDetails.BatchID=BatchDetails.BatchID;
//
select * from TraineeDetails,CourseOfferingDetails, CourseDetails where CourseDetails.CourseID=CourseOfferingDetails.CourseID
and TraineeDetails.TraineeID=CourseOfferingDetails.TraineeID and CourseName='RDMS' and min(Marks);
//
select CourseID,CourseName,Prerequisite,max(Duration) from  CourseDetails where Duration=max(Duration);



































