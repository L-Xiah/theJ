GRANT SELECT, INSERT, UPDATE
ON Employee
TO User_B
WITH GRANT OPTION;
-----------------------------
GRANT SELECT
ON Department
TO User_C
WITH GRANT OPTION;
-----------------------------
GRANT SELECT, UPDATE
ON Employee
TO User_D;
-----------------------------
GRANT SELECT
ON Department
TO User_E;
-----------------------------
REVOKE SELECT, INSERT, UPDATE
ON Employee
FROM User_B
-----------------------------