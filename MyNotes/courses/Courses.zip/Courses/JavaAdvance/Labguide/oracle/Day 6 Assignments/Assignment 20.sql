create table EMPLOYEE(
EmpId Number(4) Primary Key,
EmpName Varchar2(15) not null,
Salary Number(7,2),
DateOfJoin Date
)
//
insert into EMPLOYEE values(1001,'Suresh',50000,to_date('2002-01-01','yyyy-mm-dd'));
insert into EMPLOYEE values(1002,'Kumar', 40000,to_date('2003-03-25','yyyy-mm-dd'));
insert into EMPLOYEE values(1003,'Vijay', 70000,to_date('2001-08-15','yyyy-mm-dd'));
//
CREATE VIEW EMPLOYEE_VIEW
AS SELECT *
FROM
EMPLOYEE
//
SELECT *
FROM EMPLOYEE_VIEW
//验证：
INSERT INTO EMPLOYEE_VIEW(EmpName,Salary,DateOfJoin)
VALUES('Kiran',2500,'01-Jan-2002');
//
INSERT INTO EMPLOYEE_VIEW(EmpId,Salary,DateOfJoin)
VALUES(1004,60000,'01-Jan-2004');
//
INSERT INTO EMPLOYEE_VIEW(EmpId,EmpName,DateOfJoin)
VALUES(1004,‟Arun‟,'01-Jan-2004');
//
DROP TABLE EMPLOYEE;
SELECT * FROM EMPLOYEE_VIEW;
//
SELECT * FROM EMPLOYEE_VIEW;
SELECT * FROM EMPLOYEE_VIEW;














