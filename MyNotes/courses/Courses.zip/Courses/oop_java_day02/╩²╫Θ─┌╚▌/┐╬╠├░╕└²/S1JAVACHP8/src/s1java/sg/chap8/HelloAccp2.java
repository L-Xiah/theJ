package s1java.sg.chap8;

public class HelloAccp2 {
	public static void main(String[] args) {
		int[] score = new int[];
		score[0] = 89;
		score[1] = 63;
		System.out.println(score[0]);
	}
}
