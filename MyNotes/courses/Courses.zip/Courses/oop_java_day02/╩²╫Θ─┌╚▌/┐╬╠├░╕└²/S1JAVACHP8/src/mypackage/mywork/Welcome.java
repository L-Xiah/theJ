package mypackage.mywork;
import java.util.*;
public class Welcome {
    
	/**
	 * ���û��ʺ�
	 */
	public void sayHello(){
		Scanner input = new Scanner(System.in);
		System.out.print("���ʲô��");
		String name = input.next();
		System.out.println(name + ", ��ã�");
	}
	
	
	public static void main(String[] args) {
		Welcome welcome = new Welcome();
		welcome.sayHello();
	}
}
