public class HelloAccp6 {
	public static void main(String[] args) {
		int aScore = 80; // AѧԱ�ɼ�
		int bScore; // BѧԱ�ɼ�
		bScore = aScore;
		System.out.println("BѧԱ�ĳɼ��ǣ� " + bScore);
	}
}
