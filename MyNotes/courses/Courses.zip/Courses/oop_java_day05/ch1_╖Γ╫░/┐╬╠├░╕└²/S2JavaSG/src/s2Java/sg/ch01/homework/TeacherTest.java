package s2Java.sg.ch01.homework;

class Teacher1 {
//	public Techer1(){
//	}
}
class Teacher2 {
	public void Teacher2(String name){
	}
}
public class TeacherTest {
	public static void main(String[] args) {
		//Teacher1   t1 = new Techer1();
		//Teacher2   t2 = new Teacher2("Mr lee");
	}
}
