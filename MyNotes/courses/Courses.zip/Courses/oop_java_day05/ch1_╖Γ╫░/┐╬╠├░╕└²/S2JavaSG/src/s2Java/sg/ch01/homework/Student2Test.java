package s2Java.sg.ch01.homework;

class Student2{
	private String name;
	private int age;
	private String sex;
	private String subject;
	public Student2(String name,int age){
		this.name = name;
		this.age = age;
		this.sex = "��";
		this.subject = "ACCP";
	}
	public Student2(String name,int age,String sex, String subject){
		this.name = name;
		this.age = age;
		this.sex = sex;
		this.subject = subject;
	}
	public String introduction() {
		return "��Һã�����" + name + "���ҽ���"+ age+"��,�Ա���"+sex+",רҵ��"+subject;
	}
}
public class Student2Test {
	public static void main(String[] args){
		Student2 s1 = new Student2("����",20);
		Student2 s2 = new Student2("����",22,"Ů","BENET");
		System.out.println(s1.introduction());
		System.out.println(s2.introduction());
	}

}
