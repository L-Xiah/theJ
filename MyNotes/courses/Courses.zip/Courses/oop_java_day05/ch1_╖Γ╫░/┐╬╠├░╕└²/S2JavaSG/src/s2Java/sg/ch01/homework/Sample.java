package s2Java.sg.ch01.homework;

public class Sample {
//	public void amethod(int i, String s){ }
//	public void amethod(String s, int i){ } 
//	public int amethod(String s1, String s2) { } 
//	private void amethod(int i, String mystring){ }
//	public void Amethod(int i, String s) { } 
//	private  void amethod(int i); 
}