package s2Java.sg.ch01;

public class Mystery {
	private String s = "nothing";
	public void Mystery() {
		s = "constructor";
	}
	public Mystery(){
		s = "hello";
	}
	public Mystery(String str){
		s = str;
	}
	void go() {
		System.out.println(s);
	}
	public static void main(String[] args) {
		Mystery m1 = new Mystery();
		m1.go();
		Mystery m2 = new Mystery("story");
		m2.go();
	}
	}

