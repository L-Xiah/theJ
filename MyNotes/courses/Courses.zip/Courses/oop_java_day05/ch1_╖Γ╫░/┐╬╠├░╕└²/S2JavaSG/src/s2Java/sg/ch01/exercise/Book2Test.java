package s2Java.sg.ch01.exercise;

class Book2{
	private String title;
	private int pageNum;
	public Book2(String title,int pageNum){
		this.title = title;
		if(pageNum<200){
			System.out.println("ҳ����������200ҳ��");
			this.pageNum = 200;
		}else
			this.pageNum = pageNum;
	}
	public void detail(){
		System.out.println("������"+title+",ҳ��:"+pageNum);
	}
	
}
public class Book2Test {

	public static void main(String[] args) {
		Book2 b = new Book2("Java����",107);
		b.detail();
	
	}

}
