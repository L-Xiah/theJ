package s2Java.sg.ch01;

public class AccpTeacher5Test {
	public static void main(String[] args) {
		AccpTeacher5  teacher = new AccpTeacher5();
		System.out.println("��Ա����Ϊ:"+teacher.getName());
	}
}

