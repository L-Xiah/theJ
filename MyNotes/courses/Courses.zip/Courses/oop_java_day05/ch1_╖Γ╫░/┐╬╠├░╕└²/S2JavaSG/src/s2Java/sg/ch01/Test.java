package s2Java.sg.ch01;

public class Test {
	public static void main(String[] args){
		int i =0;
		char c ='z';
		String str = "hello";
		System.out.println(i);
		System.out.println(c);
		System.out.println(str);
		
	}
}
