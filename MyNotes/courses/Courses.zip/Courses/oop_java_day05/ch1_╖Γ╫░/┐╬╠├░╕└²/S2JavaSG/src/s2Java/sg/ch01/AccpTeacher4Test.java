package s2Java.sg.ch01;
public class AccpTeacher4Test {
	public static void main(String[] args) {
		AccpTeacher4  teacher = new AccpTeacher4();
		teacher.setName("�");
		teacher.setAge(23);
		teacher.setEducation("����");
		System.out.println(teacher.introduction());
	}
}
