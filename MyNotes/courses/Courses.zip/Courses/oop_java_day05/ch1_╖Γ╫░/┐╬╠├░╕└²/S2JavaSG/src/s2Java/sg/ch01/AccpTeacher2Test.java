/*
 * s2jsp.sg.AccpTeacher2Test.java
 * 2007-5-29
 * 2u^j2JavaJavaprivate
 * ,AccpTeacher
 */
package s2Java.sg.ch01;

public class AccpTeacher2Test {
	public static void main(String[] args) {
		AccpTeacher2 teacher = new AccpTeacher2();
		teacher.setName("�");
		teacher.setAge(10);
      //������ҽ��ܵ�����
		System.out.println(teacher.introduction());

	}
}

