package s2Java.sg.ch01;
public class AccpTeacher6Test {
	public static void main(String[] args) {
		AccpTeacher6  teacher =  new AccpTeacher6("�",23,"����","��ѯʦ");
		System.out.println(teacher.introduction());
	}
}



