package s2Java.sg.ch01.exercise;

class Book{
	private String title;
	private int pageNum;
	public int getPageNum() {
		return pageNum;
	}
	public void setPageNum(int pageNum) {
		if(pageNum<200){
			System.out.println("ҳ����������200ҳ��");
			this.pageNum = 200;
		}else
			this.pageNum = pageNum;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public void detail(){
		System.out.println("������"+title+",ҳ��:"+pageNum);
	}
	
}

public class BookTest {
	public static void main(String args[]){
		Book b = new Book();
		b.setTitle("Java��������");
		b.setPageNum(109);
		b.detail();
	}

}
