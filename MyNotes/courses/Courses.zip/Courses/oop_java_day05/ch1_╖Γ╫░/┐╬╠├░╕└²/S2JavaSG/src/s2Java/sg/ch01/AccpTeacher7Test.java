package s2Java.sg.ch01;


public class AccpTeacher7Test {

	public static void main(String[] args) {
		AccpTeacher7  teacher1 = new AccpTeacher7("�");
		System.out.println(teacher1.introduction());

		AccpTeacher7  teacher2 = new AccpTeacher7("����", "�������");
		System.out.println(teacher2.introduction());
	}

}
