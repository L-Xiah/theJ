package s2Java.sg.ch02;

public class MyObject {
	public static void main(String[] args){
		MyObject obj = new MyObject();
	}

}
