﻿package s2Java.sg.ch02.exercise;
class Animal{
	public void sleep(){
		System.out.println("����˯���أ�");
	}
	public void eat(){}
}
class Tiger extends Animal{
	public void eat(){
		System.out.println("��ϲ�����⣡");
	}
}
class Rabbit extends Animal{
	public void eat(){
		System.out.println("��ϲ���Բݺ���ˣ�");
	}
}

public class AnimalTest {
	public static void main(String[] args) {
		Tiger t = new Tiger();
		t.sleep();
		t.eat();
		Rabbit r = new Rabbit();
		r.sleep();
		r.eat();
	}
}
