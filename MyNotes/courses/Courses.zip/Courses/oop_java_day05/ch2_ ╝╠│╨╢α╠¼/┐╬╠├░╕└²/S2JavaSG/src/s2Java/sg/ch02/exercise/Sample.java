package s2Java.sg.ch02.exercise;

public class Sample {

	public static void main(String[] args) {
		Child c = new Child();
		//c.setName("child");
		c.method();
		
	}
}

class Base extends Object{
	private String name;
	public Base(){
		name="Base constructor";
	}
	public Base(String pName){
		name = pName;
	}
	public void method(){
		System.out.println(name);
	}
}
class Child extends Base{

	public void method(String s){
		
	}
	public void method(){
		System.out.println("Child method");
	}
//	public int method(){
//		
//	}
//	private void method(){
//	
//	}
	public Child(){
		super("Child constructor");
		//name="cc";
	}
	public void setName(String pName){
		//name =pName;
	}
	
}


