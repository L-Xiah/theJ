package s2Java.sg.ch02.exercise;

class Instrument{
	public void play(){}
}
class Piano extends Instrument{
	public void play(){
		System.out.println("ʹ�ø������࣡");
	}
}
class Violin extends Instrument{
	public void play(){
		System.out.println("ʹ��С�������࣡");
	}
}
public class InstrumentTest {
   public void testPlay(Instrument ins){
	   ins.play();
   }
   public static void main(String[] args){
	   InstrumentTest test = new InstrumentTest();
	   test.testPlay(new Piano());
	   test.testPlay(new Violin());
   }
}
