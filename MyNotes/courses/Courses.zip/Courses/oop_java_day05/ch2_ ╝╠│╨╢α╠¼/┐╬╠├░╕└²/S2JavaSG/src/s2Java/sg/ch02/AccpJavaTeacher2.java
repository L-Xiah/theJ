package s2Java.sg.ch02;

public class AccpJavaTeacher2 extends AccpTeacher {
	public AccpJavaTeacher2(String myName, String mySchool) {
		super(myName, mySchool); //���ø���Ĺ��췽��
	}
	public void giveLesson(){
		System.out.println("���� Eclipse");
		super.giveLesson();
	}
}
