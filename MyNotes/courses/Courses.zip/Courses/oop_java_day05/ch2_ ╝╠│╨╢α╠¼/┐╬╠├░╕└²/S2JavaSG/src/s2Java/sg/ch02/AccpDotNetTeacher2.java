package s2Java.sg.ch02;
public class AccpDotNetTeacher2 extends AccpTeacher {
	public AccpDotNetTeacher2(String myName, String mySchool) {
		super(myName, mySchool); //���ø���Ĺ��췽��
	}
	public void giveLesson(){
		System.out.println("����Visual studio .net");
		super.giveLesson();
	}
}