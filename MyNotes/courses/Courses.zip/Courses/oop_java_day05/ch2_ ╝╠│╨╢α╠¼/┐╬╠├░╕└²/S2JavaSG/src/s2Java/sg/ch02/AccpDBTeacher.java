package s2Java.sg.ch02;

public class AccpDBTeacher extends AccpTeacher {
	public AccpDBTeacher(String myName, String mySchool) {
		super(myName, mySchool); //���ø���Ĺ��췽��
	}
	public void giveLesson(){
		System.out.println("����Sql Server");
		super.giveLesson();
	}
}
