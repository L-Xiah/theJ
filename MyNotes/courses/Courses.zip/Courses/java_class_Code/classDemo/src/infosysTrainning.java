
class infosys {
	public String schoolName;
	public String schoolAddress;
	public int classNum;
	
	//定义类的行为（方法）
	public String toString()
	{
		return "Infosys Trainning Center"+schoolName+"位于"+schoolAddress+"\n"+"一共有"+classNum+"教室";
	}
	public void showInfo(String name,String address,int number)
	{
		System.out.println("Trainning Name"+name+",Located in "+address+"there are totally "+number+" classrooms");		
	}

}
public class infosysTrainning{
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//创建类的对象,在创建对象时，通过关键字new，是在计算机heap（堆区）给对象分配一个空间；
		infosys trainCenterChina= new infosys();
		//infosys trainCenterJapan= new infosys();
		infosys trainCenterIndian = new infosys();
		//给trainCenterChina属性赋初始值
		trainCenterChina.schoolName="中国嘉兴Infosys培训中心";
		trainCenterChina.schoolAddress="浙江省嘉兴市南湖区";
		trainCenterChina.classNum = 10;
		
		/*String info = trainCenterChina.toString();
		System.out.println(info);
		
		trainCenterIndian.schoolName="Indian Mysore ETA Center";
		trainCenterIndian.schoolAddress="Mysore,Indian";
		trainCenterIndian.classNum=100;
		info = trainCenterIndian.toString();
		System.out.println(info);*/
		trainCenterChina.showInfo(trainCenterChina.schoolName, trainCenterChina.schoolAddress, trainCenterChina.classNum);
		
		
	}
}