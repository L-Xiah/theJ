
public class chatRobot {
	String name;
	int fulllevel;
	
	public chatRobot()
	{}
	
	public chatRobot(String _name)
	{
		this.name = _name;
		
	}
	
	void Sayhello()
	{
		System.out.println("你好，我是"+name+",欢迎进入***聊天平台");
	}
	
	int Eating(int num)
	{
		fulllevel +=num;
		return fulllevel;
	}
	int Speaking(String str)
	{
		if(fulllevel<=0)
		{
			System.out.println("没有能量了，给点正能量呗");
			
		}	
		if(str.contains("姓名")||str.contains("name")||str.contains("名字"))
		{
			this.Sayhello();
		}
		else if(str.contains("女朋友")||str.contains("GF")||str.contains("朋友")||str.contains("friend"))
		{
			System.out.println("本人年龄尚小，暂时不予考虑");
			
		}
		else if(str.contains("游戏")||str.contains("LOL"))
		{
			System.out.println("主人，主人该去上课了耶");
		}
		else
		{
			System.out.println("亲，不好意思，没听懂，请再说一遍");
		}
		fulllevel--;
			return fulllevel;
	}
}
