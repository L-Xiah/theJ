import java.util.Scanner;


public class robotDemo {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		factoryRobot frobot = new factoryRobot();
		System.out.println("输入要选择聊天的对象 a:小r\tb:小I");
		Scanner input = new Scanner(System.in);
		String option = input.nextLine();
		chatRobot crobot = frobot.getRobot(option);
		crobot.fulllevel=2;
		crobot.Sayhello();
		crobot.Speaking("name");
		Math.abs(-1);
	}

}

