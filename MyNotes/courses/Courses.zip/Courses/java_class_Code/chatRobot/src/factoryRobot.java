
public class factoryRobot {
	public chatRobot getRobot(String type)
	{
		chatRobot robot = null;
		if(type.contains("小R")||type.contains("小r")||type.contains("r"))
			robot = new chatRobot("小r");
		else if(type.contains("小I")||type.contains("小i")||type.contains("i"))
			robot = new chatRobot("小I");
		return robot;
	}
}
