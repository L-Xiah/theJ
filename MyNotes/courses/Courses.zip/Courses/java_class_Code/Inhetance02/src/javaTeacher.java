
public class javaTeacher extends Teacher{
	//String skills;
	public javaTeacher(String _name,String _school)
	{
		super(_name,_school);
		//调用父类的构造方法,完成对属性的初始化操作
	}
	public void giveLesson()
	{
		System.out.println("java老师，正在打开Eclipse工具,准备上课");
		super.giveLesson();
	}
}
