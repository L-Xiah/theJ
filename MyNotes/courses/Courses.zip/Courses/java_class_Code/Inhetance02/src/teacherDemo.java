
public class teacherDemo {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//javaTeacher zhangsan = new javaTeacher("张三", "上海 Infosys DC");
		//netTeacher  lisi = new netTeacher("李四", "北京 Infosys DC");
		//Teacher wangwu = new javaTeacher("王五","深圳 Infosy DC");
//		zhangsan.giveLesson();
//		zhangsan.Introduce();
//		lisi.giveLesson();
//		lisi.Introduce();
		//wangwu.giveLesson();
		//wangwu.Introduce();
		
		//javaTeacher zhaoliu = new Teacher("赵六","大连 Infosys DC");
		//如果一个父类引用指向一个子类对象，再将父类的引用赋值给另外一个子类引用时，
		//此时需要强制类型转换；
//		Teacher zhaoliu = new javaTeacher("赵六","青岛 Infosys DC");
//		javaTeacher wanger = (javaTeacher)zhaoliu;
//		zhaoliu.giveLesson();
//		zhaoliu.Introduce();
		Object hello=123;
		System.out.println("字符串是否是Object类的实例（对象）"+(hello instanceof Object));
		System.out.println("字符串是否是Object类的实例（对象）"+(hello instanceof String));
		System.out.println("字符串是否是Object类的实例（对象）"+(hello instanceof Math));
	}

}
