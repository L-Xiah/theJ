
public class netTeacher extends Teacher{
	public netTeacher(String _name,String _school)
	{
		//调用父类的构造方法
		super(_name,_school);
	}
	public void giveLesson()
	{
		System.out.println("DOTNET 老师,正在打开Visual Studio工具，准备上课");
		super.giveLesson();
	}
}
