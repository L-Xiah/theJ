
public class Teacher {
	private String name;
	private String school;
	public Teacher(String _name,String _school)
	{
		this.name = _name;
		this.school = _school;
	}
	//定义Teacher类的方法
	public void giveLesson()
	{
		System.out.println("讲解知识点");
		System.out.println("演示知识点案例");
		
	}
	
	public void Introduce()
	{
		System.out.println("我叫"+name+",工作在"+school);
	}
	
}
