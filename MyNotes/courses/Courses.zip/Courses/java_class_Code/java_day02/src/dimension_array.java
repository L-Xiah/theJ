import java.util.Random;


public class dimension_array {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*int[] myArray = new int[5];//定义一个数组，并指定数组的长度为5
		Random ran = new Random();
		//通过随机类的对象ran来给数组进行赋值操作
		for(int i=0;i<myArray.length;i++)
		{
				myArray[i]=Math.abs(ran.nextInt()%21);
		}
		//将数组中每个元素的值输出到控制台
		for(int i=0;i<myArray.length;i++)
		System.out.println("myArray["+i+"]="+myArray[i]);*/
		
		/*String[] course = new String[]{"Html","Javascript","OOP Java","Oracle"};
		for(int i=0;i<course.length;i++)
		{
			System.out.println("course["+i+"]="+course[i]);
		}
		for(String c : course)
		{
			System.out.println(c);
		}
		String[] name = new String[5];
		name[0]="name1";
		name[1]="name2";
		name[2]="name3";
		name[3]="name4";
		name[4]="name5";
		System.out.println("Name数组中的值为");
		for(String na : name)
		{
			System.out.println(na);
		}
		name = course;
		System.out.println("course.length="+course.length+",name.length="+name.length);*/
		//定义并静态初始化一个二维数组
		/*int[][] myArray = new int[][]{{1,2,3},{4,5,6},{7,8,9}};
		for(int i=0;i<myArray.length;i++)
		{
				for(int j=0;j<myArray[i].length;j++)
				{
					System.out.print(myArray[i][j]+"\t");
				}
				System.out.println();
		}*/


		
	}

}
