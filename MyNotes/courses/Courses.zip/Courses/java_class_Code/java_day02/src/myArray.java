import java.util.Scanner;


public class myArray {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//定义一个数组，从键盘中动态赋值，并将对应的数据打印到控制台;
		//int[] myArray = {0,0,0,0,0};
		//通过键盘动态给数组进行赋值
		//Scanner input = new Scanner(System.in);
		//for(int i=0;i<5;i++)
		//	myArray[i]= input.nextInt();
		//System.out.println("myArray.length="+myArray.length);
		/*int[] arr={32,2,14,56,4};
		int max;
		int[] myarray;
		System.out.println("数组arr的长度为arr.length="+arr.length);
		//System.out.println("数组myarray的长度myarray.length="+myarray.length);
		max = arr[0];
		for(int i=0;i<arr.length;i++)
		{
			if(max < arr[i])
				max = arr[i];
			//System.out.println("arr["+i+"]"+arr[i]);
		}
		myarray = arr;//将arr数组中元素赋值给myarray
		System.out.println("数组myarray的长度为myarray.length="+myarray.length);
		System.out.println("数组中最大值max="+max);*/
		
		//通过Random类给数组赋值
		
		
	
	}

}

