import java.util.Scanner;


public class formatOutput {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//task-1 通过键盘输入一个半径，计算该半径所组成的圆的周长，面积，
		//及对应的圆球体的体积.
		/*float radius = 0.0f;
		Scanner input = new Scanner(System.in);
		System.out.println("请输入半径：");
		radius = input.nextFloat();
		double volumn = 0.0f;
		volumn = 4.0/3*3.14*radius*radius*radius;*/
		//在除法运算时，编译器会自动根据除法运算符左右两侧的数据类型来决定除法运算结果的类型
		//如果是两个整数类型的数字相除，那么结果就是整形数据，
		//如果其中有一个数据是浮点类型数据，那么结果就是浮点类型数据
		//System.out.println("体积为"+volumn);
		/*char myChar= 'M';
		int myInt = 100;
		long myLong = 10000;
		float myFloat = 3.1415926f;
		String myStr = "helloworld";
		int value = 10;
		System.out.printf("myChar=%c\n",myChar);
		System.out.printf("myInt=%d\n",myInt);
		System.out.printf("myLong=%d\n",myLong);
		System.out.printf("myFloat=%.4f\n",myFloat);
		System.out.printf("myStr=%s\n",myStr);
		//System.out.printf("unsigned value=%u\n",value);
		System.out.printf("value_o=%o\n",value);
		System.out.printf("value_hex=%x\n",value);*/
		//声明一个数组，名称为myArray
		int[] myArray;
		myArray = new int[]{7,26,2016};
		System.out.println("myArray[0]="+myArray[0]);
		System.out.println("myArray[1]="+myArray[1]);
		System.out.println("myArray[2]="+myArray[2]);
		//定义一个数组，从键盘中动态赋值，并将对应的数据打印到控制台;
		
		
		
	}

}
