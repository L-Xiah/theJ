
public class Watermelon extends Fruit{
	//private String name;
	/**
	 * @param args
	 */
	public void showInfo()
	{
		System.out.println("I am watermelon,my weight is "+weight+"g!");
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Watermelon water = new Watermelon();
		water.weight = 20;
		water.showInfo();
	}

}

