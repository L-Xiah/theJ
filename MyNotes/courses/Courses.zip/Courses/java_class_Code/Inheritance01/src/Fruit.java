
public class Fruit {
	public double weight;
	public void showInfo()
	{
		System.out.println("I am a fruit,The weight is "+weight+"g!");
	}
}
