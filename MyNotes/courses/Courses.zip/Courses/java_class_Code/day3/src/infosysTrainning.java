
public class infosysTrainning {
	//定义类的属性
	public String schoolName;
	public String schoolAddress;
	public int classNum;
	
	//定义类的行为（方法）
	public String toString()
	{
		return "Infosys Trainning Center"+schoolName+"位于"+schoolAddress+"\n"+"一共有"+classNum+"教室";
	}
}
class initailClass{
	
	public static void main(String[] args)
	{
		//创建类的对象
		infosysTrainning trainCenterChina = new infosysTrainning();
		infosysTrainning trainCenterIndian = new infosysTrainning();
		//给trainCenterChina属性赋初始值
		trainCenterChina.schoolName="中国嘉兴Infosys培训中心";
		trainCenterChina.schoolAddress="浙江省嘉兴市南湖区";
		trainCenterChina.classNum = 10;
		trainCenterChina.toString();
	}
}
