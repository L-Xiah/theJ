import java.io.IOException;
import java.util.Scanner;
public class chatRobot {
	public static void main(String[] args) throws IOException {
		Robot r1 = new Robot();
		Robot r2 = new Robot();
		r1.name = "小r";
		r1.fulllevel = 2;
		r2.name = "小I";
		r2.fulllevel = 10;
		System.out.println("请选择聊天对象 1:小r\t2:小I");
		char opt ='\0';
		Scanner input = new Scanner(System.in);
		int choice = input.nextInt();
		switch(choice)
		{
			case 1:
			
				r1.Sayhello();
				System.out.println("开始进入和"+r1.name+"的专属聊天室");
				do{
					String talk = input.nextLine();
					int power = r1.Speaking(talk);
					if(power<=0)
					{
						System.out.println("主人，你的余额不足，请充值(Y/y)");
						opt = (char)System.in.read();
						if(opt=='y'||opt=='Y')
						{
							System.out.println("请输入要聊几块钱的?");
							int recharge = input.nextInt();
							r1.Eating(recharge);
							System.out.println("充过值了，请继续聊天");
							talk = input.nextLine();
							r1.Speaking(talk);
						}
						else
						{
							System.out.println("结束本次聊天");
							return;
						}
					}
				}while(true);
			
			case 2:
				r2.Sayhello();
				break;
			default:
				break;
		}
	}
}
class Robot{
	String name;
	int fulllevel;
	
	void Sayhello()
	{
		System.out.println("你好，我是"+name+",欢迎进入***聊天平台");
	}
	
	int Eating(int num)
	{
		fulllevel +=num;
		return fulllevel;
	}
	int Speaking(String str)
	{
		if(fulllevel<=0)
		{
			System.out.println("没有能量了，给点正能量呗");
			
		}	
		if(str.contains("姓名")||str.contains("name")||str.contains("名字"))
		{
			this.Sayhello();
		}
		else if(str.contains("女朋友")||str.contains("GF")||str.contains("朋友")||str.contains("friend"))
		{
			System.out.println("本人年龄尚小，暂时不予考虑");
			
		}
		else if(str.contains("游戏")||str.contains("LOL"))
		{
			System.out.println("主人，主人该去上课了耶");
		}
		else
		{
			System.out.println("亲，不好意思，没听懂，请再说一遍");
		}
		fulllevel--;
			return fulllevel;
	}
}
