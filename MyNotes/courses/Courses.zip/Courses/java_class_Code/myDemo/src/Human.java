
public class Human {
	//定义了human类的三个属性
	public String name;
	public String gender;
	public float weight;
	
	public Human()
	{}
	
	public Human(String _name,String _gender,float _weight)
	{
		this.name = _name;
		this.gender=_gender;
		this.weight=_weight;
	}
	//定义human类的方法
	public void Eating(){
		//填充Eating方法体
		//Human human = new Human();
		System.out.println("中午吃了一碗米饭，两个大荤");
		this.Walking();
	}
	public void Walking()
	{
		System.out.println("今天从宿舍走到了教室");
	}
	//方法重载(method Overload)
	public void Walking(int steps)
	{
		
		System.out.println("今天我走了"+steps+"步，完成了既定目标");
	}
	public void Walking(String nam,int steps)
	{
		System.out.println("今天我("+nam+")走了"+steps+"步，完成了既定目标");
	}
	public void LoseWeight()
	{
		//if((gender.equalsIgnoreCase("male")&& weight>70)||(gender.equalsIgnoreCase("female")&&weight>50))
		if(gender=="male"&&weight>70)
		{
			System.out.println("主人需要去锻炼减肥了");
		}
		else
		{
			System.out.println("完美身材，请继续保持");
		}
		
	}
	public String toString()
	{
		return "我叫"+name+"，性别"+gender+"体重"+weight+"kg";
		
	}
	
}
