
public class swapNumber {
	int number1;
	int number2;
//	public swapNumber(){
//	}
	public void swap(int a,int b)
	{
		System.out.println("output1:a="+a+",b="+b);
		a = a + b;
		b = a - b;
		a = a - b;
		System.out.println("output2:a="+a+",b="+b);
	}
	
	public void swap(swapNumber sw)
	{
		System.out.println("output1:number1="+sw.number1+",number2="+sw.number2);
		sw.number1 = sw.number1+sw.number2;
		sw.number2 = sw.number1 - sw.number2;
		sw.number1 = sw.number1 - sw.number2;
		System.out.println("output2:number1="+sw.number1+",number2="+sw.number2);
	}
}
