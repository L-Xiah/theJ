import java.util.Scanner;


public class testDemo {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//创建Human类的对象 Syntax： 类名 对象名 = new 类名();
//		Human alex = new Human();
//		//通过对象来访问类中的属性和方法 语法是 对象名.属性名(方法名);
//		alex.name="鄢克";
//		alex.gender="Male";
//		alex.weight=68.0f;
		//键盘输入对象的数据
//		Scanner input = new Scanner(System.in);
//		System.out.println("请输入姓名");
//		alex.name = input.nextLine();
//		System.out.println("请输入性别");
//		alex.gender = input.nextLine();
//		System.out.println("请输入体重");
//		alex.weight = input.nextFloat();
//		String info = alex.toString();
//		System.out.println(info);
//		alex.Eating();
//		alex.LoseWeight();
//		
//		//alex.Walking();
//		//alex.Walking(1000);
//		alex.Walking(alex.name, 1);
//		//Human andy = new Human();
		//在创建leah对象的同时，直接调用带参的构造方法完成初始化操作
//		Human leah = new Human("Leah Lee","Female",50);
//		String showinfo = leah.toString();
//		System.out.println(showinfo);
//		leah.Eating();
		swapNumber sw = new swapNumber();
		
		int value1 = 11;
		int value2 = 22;
		sw.number1 = value1;
		sw.number2 = value2;
		System.out.println("1 Main funtion:value1="+sw.number1+",value2="+sw.number2);
		//sw.swap(value1,value2);
		sw.swap(sw);
		System.out.println("2 Main fucntion:value1="+sw.number1+",value2="+sw.number2);
	}
}

