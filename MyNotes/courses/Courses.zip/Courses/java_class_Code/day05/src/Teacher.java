
public class Teacher {
	//定义teacher类的属性
	 private String name;
	 private int age;
	
	 //通过共有方法来访问私有属性
	 
	 public String getName()
	 {
		 return name;
	 }
	 
	 public void setName(String _name)
	 {
		 this.name = _name;
	 }
	 
	 public int getAge()
	 {
		 return age;
	 }
	 
	 public void setAge(int _age)
	 {
		 if(_age<25)
		 {	
			 System.out.println("年龄错误，最小年龄25岁");
			 this.age = 25;
		 }
		 else  
			 this.age =_age;
	 }
	 
	//定义Teacher类的方法（行为）
	public void Introduce()
	{
		System.out.println("hello,大家好!我叫"+name+",今年"+age+"岁");
		
	}
	
	
}
