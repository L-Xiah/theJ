import java.util.Scanner;


public class teacherDemo {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
			Teacher zhangsan = new Teacher();
			Scanner input = new Scanner(System.in);
//			zhangsan.name="张三";
//			//zhangsan.age=10;
//			for(;;)
//			{
//				System.out.println("请输入年龄");
//				zhangsan.age = input.nextShort();
//				if(zhangsan.age>=25)
//					break;
//			}
			zhangsan.setName("张三");
			System.out.println("输入年龄的值");
			int value = input.nextInt();
			zhangsan.setAge(value);
			zhangsan.Introduce();
	}
}
