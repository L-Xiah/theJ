
public abstract class beauty {
	public abstract void Smile();
	
	public void Sayhello()
	{
		System.out.println("Beauty Say hello");
	}
}

class Lolita extends beauty{
	public void Smile()
	{
		System.out.println("Loli type beauty:XIXI......");
	}
}

class Goddness extends beauty
{
	public void Smile()
	{
		System.out.println("Goddenss Type:Hehe.......");
	}
}

class AuditLady extends beauty
{
	public void Smile()
	{
		System.out.println("Audit Lady:Hengheng......");
	}
}


