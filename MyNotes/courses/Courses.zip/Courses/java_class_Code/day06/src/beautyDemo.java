import java.util.Scanner;


public class beautyDemo {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//beauty bea = new beauty();
		
//		Lolita loli = new Lolita();
//		loli.Sayhello();
//		loli.Smile();
//		Goddness god = new Goddness();
//		god.Sayhello();
//		god.Smile();
		Scanner input = new Scanner(System.in);
		System.out.println("input the key word of Beauty Type");
		String btype = input.nextLine();
		beautyFactory Beauty = new beautyFactory();
	
		beauty bingbing = Beauty.getBeauty(btype);
		bingbing.Sayhello();
		bingbing.Smile();
	}
}
//创建一个beautyFactory类，
//通过一个getBeauty方法来创建不同beauty类的对象，
//并调用相应的Smile方法


