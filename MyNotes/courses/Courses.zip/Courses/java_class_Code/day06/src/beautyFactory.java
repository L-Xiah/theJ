
public class beautyFactory {
	public beauty getBeauty(String type)
	{
		beauty bea = null;
		if(type.contains("Loli")||type.contains("萝莉")||type.contains("Lolita"))
			bea = new Lolita();
		else if(type.contains("Goddness")||type.contains("goddness")||type.contains("御姐"))
			bea = new Goddness();
		else if(type.contains("Audit")||type.contains("AuditLady")||type.contains("Lady"))
			bea = new AuditLady();
		return bea;
	}
}
