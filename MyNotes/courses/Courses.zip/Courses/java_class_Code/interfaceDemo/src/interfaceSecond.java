
public interface interfaceSecond {
	//定义interfaceSecond接口的抽象方法
	public void Meeting();
	public void Touring(String place);
}
