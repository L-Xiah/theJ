
public class testDemo {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Chinese chinese = new Chinese();
		chinese.name="张三";
		chinese.age = 20;
		chinese.id="10000001";
		chinese.nation="中国";
		chinese.height = 1.89f;
		chinese.Showinfo(chinese);
		System.out.println("==============================");
		Dongbeiren dongbei = new Dongbeiren("小东北",30,2.26f,"中国","20000002","大连老毕湾");
		dongbei.Showinfo(dongbei);
		dongbei.Touring("Tamil Nadu");
		dongbei.Eating();
	}

}

