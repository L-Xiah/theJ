
public interface interfaceFirst {
	//定义接口的抽象实例方法（也可以理解为抽象方法）
	public void Eating();
	public void Sleeping();
}