
public class Chinese extends People implements interfaceSecond{
	public String id;
	
	public Chinese()
	{}
	
	public Chinese(String _name,int _age,float _height,String _nation,String _id)
	{
		super(_name,_age,_height,_nation);
		this.id = _id;
	}
	
	public void Showinfo(People chi)
	{
		System.out.println("我("+this.id+") 叫"+chi.name+"今年"+chi.age+"岁了"+"身高是"+chi.height+"米"+",来自"+chi.nation);
	}
	public void Meeting()
	{
		System.out.println("中国人最喜欢开会");
	}
	public void Touring(String place){}
}
