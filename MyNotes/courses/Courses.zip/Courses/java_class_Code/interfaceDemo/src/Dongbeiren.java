
public class Dongbeiren extends Chinese implements interfaceFirst,interfaceSecond{
	public String household;
	
	public Dongbeiren()
	{}
	
	public Dongbeiren(String _name,int _age,float _height,String _nation,String _id,String _household)
	{
		super(_name,_age,_height,_nation,_id);
		this.household = _household;
	}
	
	public void Showinfo(People chi)
	{
		System.out.println("我("+this.id+") 叫"+chi.name+"今年"+chi.age+"岁了"+"身高是"+chi.height+"米"+",来自"+chi.nation+"家住"+this.household);
	}
	
	public void Eating()
	{
		System.out.println("东北人正在吃猪肉炖粉条");
	}
	public void Sleeping()
	{}
	
	public void Touring(String place)
	{
		System.out.println("东北人喜欢在"+place+"旅游");
	}
	public void Meeting()
	{}
}
