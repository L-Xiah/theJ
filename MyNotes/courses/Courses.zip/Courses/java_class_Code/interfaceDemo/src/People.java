
public abstract class People {
	//定义了人类的属性
	public String name;
	public int age;
	public float height;
	public String nation;
	public People(){}
	public People(String _name,int _age,float _height,String _nation)
	{
		this.name = _name;
		this.age = _age;
		this.height = _height;
		this.nation = _nation;
		
	}
	//定义人类的抽象方法
	public abstract void Showinfo(People p);
}

