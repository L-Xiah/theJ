
public class bankDemo {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
			//bankAccount account1 = new bankAccount("李四",200000,200.0f);
			bankAccount account1 = new bankAccount();
			account1.bankName="张三";
			account1.bankNo=100000;
			//account1.bankBalance=100.0f;
			bankAccount.bankBalance=100f;
			
			account1.Withdraw();
			account1.Deposit();
			account1.Showinfo();
	}
	Math.abs(-1);

}
