import java.util.Scanner;

//定义一个类，表示银行账户，属性有：姓名，账号，余额；
//					 方法：存款，取款，显示账户信息；
public class bankAccount {
	//定义银行账户的属性
	public String bankName;
	public long bankNo;
	public static float bankBalance;
	
	
	//无参构造方法
	public bankAccount()
	{}
	
	//带参构造方法
	public bankAccount(String _bankName,long _bankNo,float _bankBalance)
	{
		this.bankName = _bankName;
		this.bankNo = _bankNo;
		this.bankBalance = _bankBalance;
		
	}
	//定义银行账户的方法
	//取款方法
	Scanner input = new Scanner(System.in);
	public  void Withdraw()
	{
//		bankAccount bank = new bankAccount();
		System.out.println("输入要取款的金额");
		double amount = input.nextDouble();
		if(amount > bankBalance)
		{
			System.out.println("余额不足");
		}
		bankBalance -= amount;
		System.out.println("当前账号余额:"+bankBalance);
	}
	//存款方法
	public void Deposit()
	{
		System.out.println("输入要存款的金额");
		double amount = input.nextDouble();
		bankBalance += amount;
		//System.out.println("当前账号余额:"+bankBalance);
		this.Showinfo();
	}
	
	//显示账户信息
	public static void Showinfo()
	{
		bankAccount bank = new bankAccount();
		System.out.println("账号\t\t姓名\t余额");
		System.out.println(bank.bankName+"\t\t"+bank.bankNo+"\t"+bankBalance);
	}
}
