import java.util.Scanner;
public class exceptionDemo {
	public static void main(String[] args) {
//		System.out.print("请输入课程代号(1至3之间的数字):");
//		Scanner in = new Scanner(System.in);
//		try {
//		int courseCode = in.nextInt();
//		switch (courseCode) {
//			case 1:
//				System.out.println("C#编程");
//				break;
//			case 2:
//				System.out.println("Java编程");
//				break;
//			case 3:
//				System.out.println("SQL基础");
//		}
//		} catch (NullPointerException ex) {
//		        System.out.println("输入不为数字!");
//		        //ex.printStackTrace();
//		}
//		System.out.println("欢迎提出建议!");
//		}
			try{
				int i = 10/0;
			}catch (ArithmeticException e) {
				System.out.println("出现错误! 错误原因："+e.getMessage());
			}finally{
				System.out.println("进入finally了！");
			}
		}
}
