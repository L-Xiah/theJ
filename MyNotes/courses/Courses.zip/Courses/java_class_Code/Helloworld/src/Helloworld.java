import java.util.Date;



 public class Helloworld {
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//System.out.println("Hello World");
		/*System.out.print("*\n");
		System.out.print("Second Line***");
		byte mybyte = 1;
		short myshort = 10;
		int myint = 100;
		long mylong = 1000L;
		float myfloat = 3.14f; //浮点类型的数据默认的数据是double类型
		double mydouble = 6.28001;*/
		
		
		/*Scanner input = new Scanner(System.in);
		System.out.println("请输入员工的工号:");
		int empno = input.nextInt();
		//System.out.println("输入的学员学号是:"+sid);
		System.out.println("请输入员工的年龄:");
		short age = input.nextShort();
		System.out.println("请输入员工的薪水:");
		long salary = input.nextLong();
		System.out.println("请输入员工的性别:");
		char gender = input.next().charAt(0);
		System.out.println("工号\t年龄\t工资\t性别");
		System.out.println(empno+"\t"+age+"\t"+salary+"\t"+gender);*/
		
		//从键盘输入一个用户的升高（单位为米）,一张门票价格100元；
		
		//		<= 1.2				免票
		//height	1.2<height<=1.5 	半价票
		//		height>1.5 			全票
		/*Scanner input = new Scanner(System.in);
		float height;
		float ticket = 100f;
		System.out.println("请输入身高(单位：m):");
		height = input.nextFloat();
		if(height>0&&height<=3)
		{	if(height <=1.2)
				System.out.println("免票进入");
			else if(1.2<height&&height<=1.5)
				System.out.println("半票进入，票价为"+ticket*0.5);
			else
				System.out.println("请支付全票,票价为"+ticket);
		}
		else
		{
			System.out.println("身高的数据不符合");
		}*/
		//double x = 11.635;
		//double y = 2.76;

		//System.out.printf("e 的值为 %.4f%n", Math.E);
		//System.out.printf("sqrt(%.3f) 为 %.3f%n", x, Math.sqrt(x));
		
		double d = 345.678;  
		String s = "hello!";   
		int i = 1234;  
		//"%"表示进行格式化输出，"%"之后的内容为格式的定义。  
		System.out.printf("%f",d);//"f"表示格式化输出浮点数。  
		System.out.printf("%9.2f",d);//"9.2"中的9表示输出的长度，2表示小数点后的位数。  
		System.out.printf("%+9.2f",d);//"+"表示输出的数带正负号。  
		System.out.printf("%-9.4f",d);//"-"表示输出的数左对齐（默认为右对齐）。  
		System.out.printf("%+-9.3f",d);//"+-"表示输出的数带正负号且左对齐。  
		System.out.printf("%d",i);//"d"表示输出十进制整数。  
		System.out.printf("%o",i);//"o"表示输出八进制整数。  
		System.out.printf("%x",i);//"d"表示输出十六进制整数。  
		System.out.printf("%#x",i);//"d"表示输出带有十六进制标志的整数。  
		System.out.printf("%s",s);//"d"表示输出字符串。  
		System.out.printf("输出一个浮点数：%f，一个整数：%d，一个字符串：%s",d,i,s);//可以输出多个变量，注意顺序。  
		System.out.printf("字符串：%2$s，%1$d的十六进制数：%1$#x",i,s);//"X$"表示第几个变量。
		System.out.println();

	}

}

 	