package com.infosys.dao;

import java.util.ArrayList;

import com.infosys.entity.Good;

public interface IGood {

	public ArrayList<Good> queryAll();
	public Good queryGoodByGoodId(int goodId);
	public boolean addGood(Good good);
	public boolean deleteGoodByGoodId(int goodId);
}
