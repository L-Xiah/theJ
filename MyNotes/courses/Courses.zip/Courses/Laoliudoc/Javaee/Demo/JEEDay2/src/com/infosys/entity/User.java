package com.infosys.entity;

public class User {

	private String userName;
	private String userPwd;
	private int userAge;
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getUserPwd() {
		return userPwd;
	}
	public void setUserPwd(String userPwd) {
		this.userPwd = userPwd;
	}
	public int getUserAge() {
		return userAge;
	}
	public void setUserAge(int userAge) {
		this.userAge = userAge;
	}
	public User(String userName, String userPwd, int userAge) {
		super();
		this.userName = userName;
		this.userPwd = userPwd;
		this.userAge = userAge;
	}
	public User(String userName, String userPwd) {
		super();
		this.userName = userName;
		this.userPwd = userPwd;
		
	}
	public User() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
}
