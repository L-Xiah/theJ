package com.infosys.dao;

public class UserDao implements IUser {

	public boolean validate(String userName, String userPwd) {
		// �ж�userName��userPwd�Ƿ��ǺϷ��û�
		if (userName.equals("James") && userPwd.equals("123")) {
			return true;
		} else {
			return false;
		}
	}

}
