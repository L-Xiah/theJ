package com.infosys.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.infosys.dao.UserDao;
import com.infosys.entity.User;

/**
 * Servlet implementation class LoginAction
 */
public class LoginAction extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginAction() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// ��ÿͻ��˴�������Ϣ
		Object userName = request.getParameter("userName");
		System.out.println(userName.toString());
		Object userPwd = request.getParameter("pwd");
		// ���û������������ӵ��Ự
		HttpSession session = request.getSession(true);
		
		System.out.println(session.isNew());
		session.setMaxInactiveInterval(900);
		session.setAttribute("good", "goodgood");
		// ����UserDao��������¼����
		UserDao userDao = new UserDao();
		boolean flag = userDao.validate(userName.toString(), userPwd.toString());
		// ���ݲ�ѯ���������һ�¸���ͼ���ڲ���ת���ض���
		if (flag) {
			/*request.setAttribute("good", "goodgood");
			
			request.getRequestDispatcher("index.jsp").forward(request, response);*/
			
			session.setAttribute("loginUser", new User(userName.toString(), userPwd.toString()));
			
			response.sendRedirect("index.jsp");
		} else {
			response.sendRedirect("login.jsp");
		}
		// request.getServletContext()
		
		// ����������ֵ
		/*Object objTest = request.getParameter("test");
		System.out.println(objTest);
		Object objChampin = request.getParameter("champin");
		int champinTimes = Integer.parseInt(objChampin.toString());
		System.out.println(champinTimes);
		// ��ÿͻ��˿ռ��е�ֵ
		Object sexTemp = request.getParameter("gender");
		System.out.println(sexTemp);
		System.out.println(request.getParameter("education"));*/
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
