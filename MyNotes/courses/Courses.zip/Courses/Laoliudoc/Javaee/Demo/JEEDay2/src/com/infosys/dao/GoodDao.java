package com.infosys.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.infosys.dbhelper.DBHelper;
import com.infosys.entity.Good;

public class GoodDao implements IGood {

	public ArrayList<Good> queryAll() {
		ArrayList<Good> goods = new ArrayList<Good>();
		// �������Ӷ���
		Connection con = DBHelper.getConnection();
		// ��ò������ݿ����
		String sql = "select * from goods";
		PreparedStatement pstl = null;
		// ������¼������
		ResultSet res = null;
		try {
			pstl = con.prepareStatement(sql);
			res = pstl.executeQuery();
			Good good = null;
			while (res.next()) {
				good = new Good();
				int goodId = res.getInt("goodid");
				String goodName = res.getString("goodName");
				double goodPrice = res.getDouble("goodPrice");
				int goodBalance = res.getInt("goodBalance");
				String goodDesc = res.getString("goodDesc");
				String goodPic = res.getString("goodPic");
				good.setGoodId(goodId);
				good.setGoodName(goodName);
				good.setGoodPrice(goodPrice);
				good.setGoodBalance(goodBalance);
				good.setGoodDesc(goodDesc);
				good.setGoodPic(goodPic);
				// �ѵ�ǰgood���ӵ�����
				// ִ�в�ѯ��������ü�¼�������������뼯��
				goods.add(good);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			DBHelper.close(con, pstl, res);
		}
		
		
		// ���ؼ���
		return goods;
	}

	public Good queryGoodByGoodId(int goodId) {
		// TODO Auto-generated method stub
		return null;
	}

	public boolean addGood(Good good) {
		// TODO Auto-generated method stub
		return false;
	}

	public boolean deleteGoodByGoodId(int goodId) {
		// TODO Auto-generated method stub
		return false;
	}

}
