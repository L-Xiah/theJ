package com.infosys.dao;

public interface IUser {

	public boolean validate(String userName, String userPwd);
}
