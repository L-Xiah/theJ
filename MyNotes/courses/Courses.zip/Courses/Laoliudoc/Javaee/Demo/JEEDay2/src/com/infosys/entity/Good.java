package com.infosys.entity;

public class Good {

	// Goods(goodId,goodName,goodPrice,goodBalance,goodDesc,goodPic)
	private int goodId;
	private String goodName;
	private double goodPrice;
	private int goodBalance;
	private String goodDesc;
	private String goodPic;
	public int getGoodId() {
		return goodId;
	}
	public void setGoodId(int goodId) {
		this.goodId = goodId;
	}
	public String getGoodName() {
		return goodName;
	}
	public void setGoodName(String goodName) {
		this.goodName = goodName;
	}
	public double getGoodPrice() {
		return goodPrice;
	}
	public void setGoodPrice(double goodPrice) {
		this.goodPrice = goodPrice;
	}
	public int getGoodBalance() {
		return goodBalance;
	}
	public void setGoodBalance(int goodBalance) {
		this.goodBalance = goodBalance;
	}
	public String getGoodDesc() {
		return goodDesc;
	}
	public void setGoodDesc(String goodDesc) {
		this.goodDesc = goodDesc;
	}
	public String getGoodPic() {
		return goodPic;
	}
	public void setGoodPic(String goodPic) {
		this.goodPic = goodPic;
	}
	public Good(int goodId, String goodName, double goodPrice, int goodBalance,
			String goodDesc, String goodPic) {
		super();
		this.goodId = goodId;
		this.goodName = goodName;
		this.goodPrice = goodPrice;
		this.goodBalance = goodBalance;
		this.goodDesc = goodDesc;
		this.goodPic = goodPic;
	}
	public Good() {
		super();
		
	}
	
}
