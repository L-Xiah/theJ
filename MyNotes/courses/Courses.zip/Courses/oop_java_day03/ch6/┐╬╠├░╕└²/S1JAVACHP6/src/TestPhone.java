
public class TestPhone {
	/**
	 * ����
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		Phone phone = new Phone();
		phone.brand = "����";
		phone.type = "SGH-D908";
		System.out.println(phone);
	}
}
