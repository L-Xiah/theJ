package s2Java.sg.ch04;
public class Test {
	public static void foo(){ 
		try { 
			String s = null;
			String s2 = s.toLowerCase();
		}catch(NullPointerException e){ 
			System.out.print("2"); 
		}finally{ 
			System.out.print("3"); 
		} 
		System.out.print("4"); 
	} 
	public static void main(String args[]){ 
		foo(); 
	} 
}
