package s2Java.sg.ch04.homework;

public class ArrayIndexExceptionTest {
	public static void main(String[] args) {
		try{
			int[] arr = new int[5];
			for(int i=0;i<6;i++)
				System.out.println(arr[i]);
		}catch (ArrayIndexOutOfBoundsException e) {
			System.out.println("���鳤��Խ��! ");
		}
	}

}
