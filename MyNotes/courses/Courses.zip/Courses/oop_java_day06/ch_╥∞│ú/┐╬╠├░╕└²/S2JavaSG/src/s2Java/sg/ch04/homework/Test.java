package s2Java.sg.ch04.homework;

public class Test {
	public static void foo(int i){ 
		try { 
			if(i==1){
				throw new Exception(); 
			} 
			System.out.print("1"); 
		}catch(Exception e){ 
			System.out.print("2"); 
		}finally{ 
			System.out.print("3"); 
		} 
		System.out.print("4"); 
	} 
	public static void main(String args[]){ 
		foo(1); 
	} 
}

