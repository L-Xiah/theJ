/*
 * s2jsp.sg.ch05.AccpTeacherTest.java
 * 2007-5-29
 * 5u^j5JavaJavathrows
 */
package s2Java.sg.ch04;

public class AccpTeacherTest {
	public static void main(String[] args) {
		AccpTeacher teacher = new AccpTeacher();
		try {
			teacher.setId("088");
		} catch (IllegalArgumentException ex) {
			System.out.println(ex.getMessage());
		}

	}
}
