package s2Java.sg.ch03.exercise;


public class ConstantsTest {
	public static void main(String[] args){
		int i = Constants.MAX - Constants.MIN;
		System.out.println("����֮���ǣ�"+i);
	}

}
