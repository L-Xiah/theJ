/*
 * s2jsp.sg.ch04.AccpSchoolType.java
 * 2007-5-29
 * 4u^j4JavaJavaij
 */
package s2Java.sg.ch03;

public interface AccpSchoolType {
    public static final String ACCP = "ACCP��������";
    public static  final String BENET = "BENETֱӪ����";
}
