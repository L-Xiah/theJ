package s2Java.sg.ch03.homework;

import s2Java.sg.ch03.exercise.Constants;

public class Test {
	public static void main(String[] args) {
//		Constants con = new Constants();
//		System.out.println(con.MAX);

//		int i = 50;
//		if(i>Constants.MAX){
//		Constants.MAX = i;
	}
}




