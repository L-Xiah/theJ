package s2Java.sg.ch03;

public class Week {
	private int days = 7;
	public static void main(String[] args) {
		Week w = new Week();
		w.days ++;
		System.out.println("һ����"+w.days+"��");
	}
}
