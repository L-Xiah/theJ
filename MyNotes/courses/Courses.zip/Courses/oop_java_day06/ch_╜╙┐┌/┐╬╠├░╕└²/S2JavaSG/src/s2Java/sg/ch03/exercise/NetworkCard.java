package s2Java.sg.ch03.exercise;

public class NetworkCard implements PCI{
	public void start(){
		System.out.println("Send...");
	}
	public void stop(){
		System.out.println("Network stop!");
	}
}

