package s2Java.sg.ch03;

public class Printer {
	public void print(String content) {
		System.out.println("��ʼ��ӡ��");
		System.out.println(content);
	}
}