package s2Java.sg.ch03.exercise;

class MainBoard{
	public void usePCICard(PCI p){
		p.start();
		p.stop();
	}
}