package s2Java.sg.ch03.homework;

public interface Animal {
	void voice(); 

}

class Dog implements Animal { 
	public void voice() { 
		System.out.println("W W!"); 
	} 
} 
class Cat implements Animal { 
	public void voice() { 
		System.out.println("M M!"); 
	} 
} 

class Store { 
	public static Animal get( String choice ) { 
		if ( choice.equalsIgnoreCase( "dog" )) { 
			return new Dog(); 
		} else { 
			return new Cat(); 
		} 
	} 
} 

class Pig implements Animal { 
	public void voice() { 
		System.out.println("O O!"); 
	} 
} 

class Store2{
	public static Animal get( String choice ) { 
		if ( choice.equalsIgnoreCase( "dog" )) { 
			return new Dog(); 
		} else if ( choice.equalsIgnoreCase( "pig" )) { 
			return new Pig(); 
		} else
			return new Cat(); 
	} 
}