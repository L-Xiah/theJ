package s2Java.sg.ch03.homework;

public interface Utility {
	//private int MAX_SIZE = 20;
	int MIN_SIZE = 10;
//	void use(){
//		System.out.println("using it");
//	}
//	private int getSize();
//	void setSize(int i);
}

class FourWheeler implements Utility{}
class Car extends FourWheeler{}
class Truck extends FourWheeler{}
class Bus extends FourWheeler{}

class Phone implements Utility { 
	void use(){
		System.out.println("using phone");
	}
}