package s2Java.sg.ch03.exercise;

class SoundCard implements PCI{
	public void start(){
		System.out.println("Du du...");}
	public void stop(){
		System.out.println("Sound stop!");}
}

