package s2Java.sg.ch03;

public class BlackPrinter implements PrinterFace {
	/**
	 * ��ӡ����
	 */
	public void print(String content) {
		System.out.println("�ڰ״�ӡ��");
		System.out.println(content);
	}

}
