package s2Java.sg.ch03.exercise;

public interface PCI {
	void start(); 
	void stop();
}

