package s2Java.sg.ch03.homework;

public class AnimalTest {
	public static void main(String[] args) {
		 Animal a1 = Store.get("dog");
		 a1.voice();
	}

}
