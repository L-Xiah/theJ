package s2Java.sg.ch03.homework;

public class Animal2Test {
	public static void main(String[] args) {
		 Animal a1 = Store2.get("pig");
		 a1.voice();
	}
}
