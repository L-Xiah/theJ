package s2Java.sg.ch03.exercise;
public class Assembler {
	public static void main(String[] args) {
		MainBoard mb=new MainBoard();
		PCI nc=new NetworkCard();
		mb.usePCICard(nc);
		PCI sc=new SoundCard();		
		mb.usePCICard(sc);
		
	}
}