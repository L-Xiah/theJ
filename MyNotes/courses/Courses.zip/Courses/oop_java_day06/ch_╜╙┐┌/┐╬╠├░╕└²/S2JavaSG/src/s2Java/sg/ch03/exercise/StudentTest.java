package s2Java.sg.ch03.exercise;

import s2Java.sg.ch03.*;
public class StudentTest {
	public static void main(String[] args){
		AccpSchool2 school = new AccpSchool2();
		school.print(new AccpStudent());
	}

}
