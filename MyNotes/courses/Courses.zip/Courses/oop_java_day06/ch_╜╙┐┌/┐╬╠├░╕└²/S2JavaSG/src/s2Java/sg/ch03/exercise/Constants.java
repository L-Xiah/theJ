package s2Java.sg.ch03.exercise;

public interface Constants {
	int MAX = 10000;
	int MIN = 1;
}
