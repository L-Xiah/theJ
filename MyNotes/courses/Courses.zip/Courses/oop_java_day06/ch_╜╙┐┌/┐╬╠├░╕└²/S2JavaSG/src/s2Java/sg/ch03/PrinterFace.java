package s2Java.sg.ch03;

public interface PrinterFace {
    public void print(String content);
}
