/*
 * s2jsp.sg.ch04.Introduceable.java
 * 2007-5-29
 * 4u^j2JavaJavaL
 */
package s2Java.sg.ch03;

public interface Introduceable {
	public String detail();
}

