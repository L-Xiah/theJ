package s1java.sg.chap9;

/**
 * С��2���������
 */
public class XiaoYuer {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		String word = "Hello,      ";
		word = word.trim();
		String s = word.concat("С���!");
		int index1 = s.indexOf(',');
		int index2 = s.indexOf('!');
		System.out.println(s.substring(index1 + 1, index2));

	}

}
