package s1java.sg.chap9;

/**
 * ե֭��
 */
public class Zhazhi {
	/**
	 * ե֭����
	 * 
	 * @param fruit ˮ��
	 * @return juice ��֭��
	 */
	public String zhazhi(String fruit) {
		String juice = fruit + "֭";
		return juice;
	}

}
