package s1java.sg.chap9;

public class HelloAccp6 {

	public static void main(String[] args) {
		Zhazhi myZhazhi = new Zhazhi();
		String myFruit = "ƻ��";
		String myJuice = myZhazhi.zhazhi(myFruit);
		System.out.println(myJuice);
	}

}
