package com.wxws.sms;

import java.util.Scanner;

/**
 * ��9�½׶�2
 */
public class Pay {
	/* ��Ʒ��Ϣ */
	public String[] goodsName;
	public double[] goodsPrice;

	/* ��Ա��Ϣ */
	public int[] custNo;
	public String[] custBirth;
	public int[] custScore;

	/**
	 * �������ݿ�
	 */
	public void setData(String[] goodsName1, double[] goodsPrice1, int[] custNo1, String[] custBirth1, int[] custScore1) {
		goodsName = goodsName1;
		goodsPrice = goodsPrice1;
		custNo = custNo1;
		custBirth = custBirth1;
		custScore = custScore1;
	}

	/**
	 * ����ͻ����ۿ���Ŀ
	 */
	public double getDiscount(int curCustNo, int[] custNo, int[] custScore) {
		double discount;
		int index = -1;
		for (int i = 0; i < custNo.length; i++) {
			if (curCustNo == custNo[i]) {
				index = i;
				break;
			}
		}

		// �ж��ۿ�
		if (custScore[index] < 2000) {
			discount = 0.9;
		} else if (2000 <= custScore[index] && custScore[index] < 4000) {
			discount = 0.8;
		} else if (4000 <= custScore[index] && custScore[index] < 8000) {
			discount = 0.7;
		} else {
			discount = 0.6;
		}
		return discount;
	}

}
