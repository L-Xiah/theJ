set serveroutput on;
	accept num prompt'input the worklevel:';
	declare 
		pnumber number:=&num;
	begin
		if pnumber = 3 then dbms_output.put_line('Leave 10 days');
		elsif pnumber = 4 then dbms_output.put_line('Leave 12.5 days');
		elsif pnumber = 5 then dbms_output.put_line('Leave 15 days');
		elsif pnumber = 6 then dbms_output.put_line('Leave 17.5 days');
		elsif pnumber = 7 then dbms_output.put_line('Leave 20 days');
		elsif pnumber = 8 then dbms_output.put_line('Leave 22.5 days');
		elsif pnumber = 9 then dbms_output.put_line('Leave 25 days');
		else dbms_output.put_line('wrong input');		
		end if;
	end;