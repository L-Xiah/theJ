package home;

public interface Animal {
	void sleep();

	void eat();
}
