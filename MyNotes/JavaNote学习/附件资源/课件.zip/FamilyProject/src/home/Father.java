package home;

public class Father extends Person {

	private String company;

	public Father(String name, String company) {
		super(name);
		this.company = company;
	}

	@Override
	public void work() {
		System.out.println("����" + company + "�ϰ�...");
	}

	public void smoke() {
		System.out.println("���ڳ���...");
	}
}
