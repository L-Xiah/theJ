package home;

public interface Lazy {
	void snooze();
}
