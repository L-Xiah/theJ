package home;

public abstract class Pet implements Animal {

	protected String name;

	public Pet(String name) {
		this.name = name;
	}

	abstract void bark();

	@Override
	public void sleep() {
		System.out.println("˯����...");
	}
}
