package home;

public class Child extends Person implements Play {

	private String school;

	public Child(String name, String school) {
		super(name);

		this.school = school;
	}

	@Override
	public void work() {
		System.out.println("ȥ��ѧ��...");
	}

	public void play() {
		System.out.println("������...");
	}

	@Override
	public void happy() {
		System.out.println("�������ܸ��ˣ�");
	}
}
