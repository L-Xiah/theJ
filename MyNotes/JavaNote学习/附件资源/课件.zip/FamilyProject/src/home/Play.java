package home;

public interface Play {
	void happy();
}