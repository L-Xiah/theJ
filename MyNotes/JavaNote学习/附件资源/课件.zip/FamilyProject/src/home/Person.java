package home;

public abstract class Person implements Animal {

	protected String name;

	public Person(String name) {
		this.name = name;
	}

	public abstract void work();

	@Override
	public void eat() {
		System.out.println("���ڳԷ�...");
	}

	@Override
	public void sleep() {
		System.out.println("˯����...");
	}
}
