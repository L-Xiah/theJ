package com.infy.jee.funny;

public class D extends B {
}
