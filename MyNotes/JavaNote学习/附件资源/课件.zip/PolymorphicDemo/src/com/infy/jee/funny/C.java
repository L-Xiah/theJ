package com.infy.jee.funny;

public class C extends B {
}
